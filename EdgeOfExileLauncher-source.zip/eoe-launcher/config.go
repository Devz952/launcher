package main

import (
	_ "embed"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
)

const launcherVersion = "1.0.0"

// Config describes the mod this launcher serves. Defaults are built in from launcher.config.json;
// a launcher.json placed next to the .exe overrides any of the fields.
type Config struct {
	ModName       string   `json:"modName"`       // shown in the window, e.g. "Edge of Exile"
	ModFolder     string   `json:"modFolder"`     // folder under <game>\mods
	GitHubRepo    string   `json:"githubRepo"`    // "owner/repo" whose Releases carry the mod zip
	AssetName     string   `json:"assetName"`     // optional exact zip name in each release; default: first .zip
	Preserve      []string `json:"preserve"`      // paths inside the mod folder kept from the old install
	LaunchArgs    []string `json:"launchArgs"`    // extra arguments for D2RLoader.exe
	CloseOnLaunch bool     `json:"closeOnLaunch"` // close the launcher once the game starts
	KeepBackups   int      `json:"keepBackups"`   // old versions kept after an update
}

//go:embed launcher.config.json
var defaultConfigJSON []byte

func loadConfig(exeDir string) Config {
	var c Config
	_ = json.Unmarshal(defaultConfigJSON, &c)
	if b, err := os.ReadFile(filepath.Join(exeDir, "launcher.json")); err == nil {
		_ = json.Unmarshal(b, &c)
	}
	c.GitHubRepo = normalizeRepo(c.GitHubRepo)
	if c.ModName == "" {
		c.ModName = "Edge of Exile"
	}
	if c.ModFolder == "" {
		c.ModFolder = "EdgeOfExile"
	}
	if c.KeepBackups < 0 {
		c.KeepBackups = 0
	}
	return c
}

// normalizeRepo accepts "owner/repo" or a full GitHub URL.
func normalizeRepo(s string) string {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, "https://")
	s = strings.TrimPrefix(s, "http://")
	s = strings.TrimPrefix(s, "github.com/")
	s = strings.TrimSuffix(strings.TrimSuffix(s, "/"), ".git")
	parts := strings.Split(s, "/")
	if len(parts) < 2 || parts[0] == "" || parts[1] == "" || strings.Contains(parts[0], "OWNER") {
		return ""
	}
	return parts[0] + "/" + parts[1]
}

// splitArgs splits a command line the way players type it: spaces separate, quotes group.
func splitArgs(s string) []string {
	var out []string
	var cur strings.Builder
	inQuote, have := false, false
	for _, r := range s {
		switch {
		case r == '"':
			inQuote = !inQuote
			have = true
		case (r == ' ' || r == '\t') && !inQuote:
			if have {
				out = append(out, cur.String())
				cur.Reset()
				have = false
			}
		default:
			cur.WriteRune(r)
			have = true
		}
	}
	if have {
		out = append(out, cur.String())
	}
	return out
}
