# Builds dist\EdgeOfExileLauncher.exe on your own PC.
#   powershell -ExecutionPolicy Bypass -File build.ps1
# Needs Go 1.22+ (https://go.dev/dl/). Re-run after editing launcher.config.json or anything in ui\.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

if (-not (Get-Command go -ErrorAction SilentlyContinue)) { throw "Go isn't installed: get it from https://go.dev/dl/" }

# Only needed after changing res\icon.ico or res\app.manifest.
if (-not (Test-Path rsrc_windows_amd64.syso) -or $args -contains '-icon') {
    go run github.com/akavel/rsrc@latest -manifest res\app.manifest -ico res\icon.ico -arch amd64 -o rsrc_windows_amd64.syso
    if ($LASTEXITCODE -ne 0) { throw "rsrc failed" }
}

go mod tidy
if ($LASTEXITCODE -ne 0) { throw "go mod tidy failed" }
go test ./...
if ($LASTEXITCODE -ne 0) { throw "tests failed" }

$env:CGO_ENABLED = "0"; $env:GOOS = "windows"; $env:GOARCH = "amd64"
New-Item -ItemType Directory -Force dist | Out-Null
go build -trimpath -ldflags "-s -w -H windowsgui" -o dist\EdgeOfExileLauncher.exe .
if ($LASTEXITCODE -ne 0) { throw "build failed" }
Write-Output "built: $(Resolve-Path dist\EdgeOfExileLauncher.exe)"
