module eoelauncher

go 1.22

require (
	github.com/jchv/go-webview2 v0.0.0-20250406165304-0bcfea011047
	golang.org/x/sys v0.30.0
)

require github.com/jchv/go-winloader v0.0.0-20250406163304-c1995be93bd1 // indirect

// Patched copy: dark default background, zoom and browser shortcuts off (see third_party/go-webview2/PATCHES.md).
replace github.com/jchv/go-webview2 => ./third_party/go-webview2
