# Edge of Exile Launcher

A small Windows launcher for the Edge of Exile D2R mod. It keeps the mod up to date from GitHub
Releases and starts the game through D2RLoader.

## What players see
1. Run `EdgeOfExileLauncher.exe` from anywhere. It finds Diablo II: Resurrected by itself
   (Battle.net or Steam); if it can't, it asks once for the folder that contains `D2R.exe`.
2. It checks GitHub for the newest release. If there is one, the button says **Update** (or
   **Install** the first time) and **Patch notes** shows the release text.
3. **Play** starts `D2RLoader.exe` from the game folder and closes the launcher.

The **Settings** tab (top left) holds each player's own choices, saved in
`%APPDATA%\EdgeOfExileLauncher\settings.json`:
- game folder, and whether D2RLoader was found (with a download link if not)
- close the launcher when the game starts; extra launch options for `D2RLoader.exe`
- install updates automatically; how many previous versions to keep (0–5)
- **Reinstall** (download the current version again) and **Roll back** to the newest saved
  version. Rolling back keeps the current version as a backup, carries the player's settings over,
  and switches automatic updates off so the old version stays.
- ember effects on/off, and links to the mod folder, backups folder and GitHub page

The **Plugins** tab installs D2RLoader plugins from a zip and lists every plugin it finds:
- **Install plugin zip…** reads the zip and shows where each file will go before installing.
  Zips laid out like the game folder (`d2rloader\plugins\...`) keep that layout; loose files are
  sorted by type (`.dll`/`.mpq` → `plugins`, `.json` → `patches`, `.toml` → `config`). Other files
  (readmes, pictures) are skipped. Zips that are D2RLoader itself or a whole mod are refused.
- Players choose **All mods** (`<game>\d2rloader`) or **Edge of Exile only**
  (`<game>\mods\EdgeOfExile\d2rloader`). Mod-only plugins are kept in
  `EdgeOfExileLauncher\plugin-store` and put back after every mod update or rollback.
- Existing plugin settings files (`config\*.toml`) are never overwritten. Installing a newer zip of
  the same plugin replaces it and drops files the new version no longer has.
- Each plugin can be switched off (its files get a `.disabled` ending, which D2RLoader ignores) or
  removed (files move to `EdgeOfExileLauncher\removed-plugins`; settings stay). Plugins that ship
  inside the mod are listed but can't be changed there.
- Name, version, author and description come from the plugin's own `PluginInfo`, read straight
  from the DLL without running it, with the zip name as a fallback.

The **Discord** button in the top-right corner opens https://discord.gg/6WcHuRrJH3.

If the game lives under `Program Files`, Windows has to approve writing to it: the launcher offers
"Restart as administrator" once and then continues the update on its own.

## What an update does
- Downloads the release zip to `%TEMP%`, unpacks it next to the game, and checks it really is a
  mod folder (modinfo.json, an `.mpq`, or a `d2rloader` folder).
- Copies the player's own files listed in `preserve` (default: `d2rloader/config`) from the old
  install into the new one, so their D2RLoader settings survive.
- Moves the old `mods\EdgeOfExile` to `<game>\EdgeOfExileLauncher\backups` (newest 2 kept) and the
  new one into place. If that fails, the old version is put back.
- Saves live in `Saved Games` and are never touched. The launcher refuses to update while
  `D2R.exe` or `D2RLoader.exe` is running.

## Setting it up
Edit `launcher.config.json` and rebuild (`build.ps1`), or drop a `launcher.json` next to the exe
with just the fields you want to change (see `launcher.json.example`).

| Field | Meaning |
|---|---|
| `githubRepo` | `owner/repo` (or the full GitHub URL) whose Releases hold the mod zip |
| `modFolder` | folder name under `<game>\mods` |
| `assetName` | exact zip name to download from each release; empty = first `.zip` |
| `preserve` | paths inside the mod folder that keep the player's copy on update |
| `launchArgs` | extra arguments for `D2RLoader.exe` |
| `closeOnLaunch` | close the launcher after starting the game |
| `keepBackups` | how many old versions to keep |

## Publishing an update
```
powershell -ExecutionPolicy Bypass -File make-release.ps1 -Version 1.5.0 -Repo you/edge-of-exile -Notes notes.md
```
This zips your installed `mods\EdgeOfExile`, sets `d2rloader\metadata.json` to the same version,
and publishes a GitHub Release tagged `v1.5.0` if the GitHub CLI (`gh`) is installed and signed in.
Without `gh`, create the release on github.com yourself and attach the zip. Players get it the
next time they open the launcher. Version tags are compared numerically (`v1.10.0` > `v1.9.2`).

The zip may contain the mod folder (`EdgeOfExile\...`), `mods\EdgeOfExile\...`, or the folder's
contents directly; all three work.

## Building
Needs Go 1.22+. Run `build.ps1`; the exe lands in `dist\`. `go test ./...` covers the update logic
(zip layouts, unsafe paths, keeping settings, backups, version order, downloads).

The window is HTML/CSS in `ui\` shown through Microsoft Edge WebView2, which ships with Windows 10
and 11. `ui\bg.jpg` is the background, `res\icon.ico` the icon (rebuild with `build.ps1 -icon`
after changing it).

## Credits
- Cinzel and Cinzel Decorative fonts, SIL Open Font License (`ui\FONT-LICENSE-OFL.txt`).
- [go-webview2](https://github.com/jchv/go-webview2), MIT, with small patches in `third_party`.
