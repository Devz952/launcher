package main

// Plugin manager: installs D2RLoader plugin zips into the right folders, keeps track of what it
// installed, lists every plugin it can find, and turns plugins on/off or removes them.
//
// D2RLoader looks for extensions in two places (https://d2rloader.net/docs.html):
//   <game>\d2rloader\plugins, \patches            shared: load for every mod
//   <game>\mods\<mod>\d2rloader\plugins, \patches  mod-scoped: load only with that mod
// Settings files live in the matching d2rloader\config folder. Paths below are relative to one of
// those d2rloader folders ("plugins/x.dll", "patches/y.json", "config/x.toml").

import (
	"archive/zip"
	"bytes"
	"debug/pe"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode"
)

const (
	ScopeGlobal = "global"
	ScopeMod    = "mod"
	disabledExt = ".disabled"
)

type PlanFile struct {
	Zip    string `json:"zip"`    // name inside the zip
	Rel    string `json:"rel"`    // destination relative to the d2rloader folder
	Kind   string `json:"kind"`   // plugin | data | patch | config
	Exists bool   `json:"exists"` // filled in when the destination is known
}

type InstallPlan struct {
	ID             string     `json:"id"`
	Name           string     `json:"name"`
	Version        string     `json:"version"`
	Files          []PlanFile `json:"files"`
	Skipped        []string   `json:"skipped"`
	SuggestedScope string     `json:"suggestedScope"`
}

type InstalledPlugin struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	Version     string   `json:"version"`
	Author      string   `json:"author,omitempty"`
	Description string   `json:"description,omitempty"`
	Scope       string   `json:"scope"`
	Files       []string `json:"files"`
	Enabled     bool     `json:"enabled"`
	InstalledAt string   `json:"installedAt"`
	Source      string   `json:"source"`
}

type PluginRegistry struct {
	Plugins []InstalledPlugin `json:"plugins"`
}

// PluginView is one row in the Plugins tab.
type PluginView struct {
	Key         string   `json:"key"`
	Name        string   `json:"name"`
	Version     string   `json:"version"`
	Author      string   `json:"author"`
	Description string   `json:"description"`
	Kind        string   `json:"kind"`   // plugin | patch | data
	Scope       string   `json:"scope"`  // global | mod
	Origin      string   `json:"origin"` // launcher | found | mod
	Enabled     bool     `json:"enabled"`
	Files       []string `json:"files"`
	CanToggle   bool     `json:"canToggle"`
	CanRemove   bool     `json:"canRemove"`
}

// ---------- reading a plugin zip ----------

func kindOf(rel string) string {
	lower := strings.ToLower(rel)
	switch {
	case strings.HasPrefix(lower, "config/"):
		return "config"
	case strings.HasPrefix(lower, "patches/"):
		return "patch"
	case strings.HasSuffix(lower, ".dll"):
		return "plugin"
	default:
		return "data"
	}
}

var (
	nexusName   = regexp.MustCompile(`^(.*?)-\d+-((?:\d+-)*\d+)-\d{9,}$`) // "Charm Inventory-1174-1-0-2-1760000000"
	trailingVer = regexp.MustCompile(`^(.*?)[\s_-]+v?(\d+(?:\.\d+)+)$`)    // "charm-inv-v1.0.2"
	slugRe      = regexp.MustCompile(`[^a-z0-9]+`)
)

func slug(s string) string { return strings.Trim(slugRe.ReplaceAllString(strings.ToLower(s), "-"), "-") }

// prettyName turns "d2rl-charm-inv" into "Charm Inv".
func prettyName(stem string) string {
	stem = strings.TrimSuffix(strings.TrimSuffix(stem, ".dll"), ".DLL")
	for _, p := range []string{"d2rl-", "d2rl_", "d2rloader-"} {
		if strings.HasPrefix(strings.ToLower(stem), p) {
			stem = stem[len(p):]
		}
	}
	words := strings.FieldsFunc(stem, func(r rune) bool { return r == '-' || r == '_' || r == ' ' })
	for i, w := range words {
		r := []rune(w)
		r[0] = unicode.ToUpper(r[0])
		words[i] = string(r)
	}
	return strings.Join(words, " ")
}

// nameFromZip reads a display name and version from download names like Nexus Mods uses.
func nameFromZip(zipName string) (name, version string) {
	stem := strings.TrimSuffix(filepath.Base(zipName), filepath.Ext(zipName))
	if m := nexusName.FindStringSubmatch(stem); m != nil {
		return strings.TrimSpace(m[1]), strings.ReplaceAll(m[2], "-", ".")
	}
	if m := trailingVer.FindStringSubmatch(stem); m != nil {
		return strings.TrimSpace(m[1]), m[2]
	}
	return stem, ""
}

// planPluginZip decides where every file in a plugin zip goes. Zips laid out like the game folder
// (d2rloader\plugins\..., or mods\<Mod>\d2rloader\...) keep their layout; loose files are sorted by
// type: .dll/.mpq to plugins, .json to patches, .toml to config.
func planPluginZip(zipPath, displayName string) (*InstallPlan, error) {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return nil, errors.New("that file isn't a readable zip")
	}
	defer zr.Close()
	plan := &InstallPlan{SuggestedScope: ScopeGlobal}
	seen := map[string]bool{}
	firstDLL := ""
	for _, f := range zr.File {
		name := strings.ReplaceAll(f.Name, `\`, "/")
		if f.FileInfo().IsDir() || strings.HasSuffix(name, "/") {
			continue
		}
		clean := path.Clean(name)
		if strings.HasPrefix(clean, "../") || clean == ".." || path.IsAbs(clean) || strings.Contains(clean, ":") {
			return nil, fmt.Errorf("the zip contains an unsafe path: %s", f.Name)
		}
		segs := strings.Split(clean, "/")
		base := strings.ToLower(segs[len(segs)-1])
		if base == "d2rloader.exe" {
			return nil, errors.New("this zip is D2RLoader itself, not a plugin. Install it from d2rloader.net into your game folder")
		}
		if base == "modinfo.json" && !containsFold(segs, "d2rloader") {
			return nil, errors.New("this zip looks like a whole mod, not a plugin")
		}
		rel := ""
		for i, s := range segs[:len(segs)-1] {
			if strings.EqualFold(s, "d2rloader") && i+1 < len(segs)-1 {
				sub := strings.ToLower(segs[i+1])
				if sub == "plugins" || sub == "patches" || sub == "config" {
					rel = sub + "/" + strings.Join(segs[i+2:], "/")
					if containsFold(segs[:i], "mods") {
						plan.SuggestedScope = ScopeMod
					}
				}
				break
			}
		}
		if rel == "" {
			for j, s := range segs[:len(segs)-1] { // inside a folder-style .mpq
				if strings.HasSuffix(strings.ToLower(s), ".mpq") {
					rel = "plugins/" + strings.Join(segs[j:], "/")
					break
				}
			}
		}
		if rel == "" {
			switch path.Ext(base) {
			case ".dll", ".mpq":
				rel = "plugins/" + segs[len(segs)-1]
			case ".json":
				rel = "patches/" + segs[len(segs)-1]
			case ".toml":
				rel = "config/" + segs[len(segs)-1]
			}
		}
		if rel == "" || strings.HasSuffix(rel, "/") {
			plan.Skipped = append(plan.Skipped, clean)
			continue
		}
		if seen[strings.ToLower(rel)] {
			return nil, fmt.Errorf("the zip has two files that would both go to %s", rel)
		}
		seen[strings.ToLower(rel)] = true
		k := kindOf(rel)
		if k == "plugin" && firstDLL == "" {
			firstDLL = segs[len(segs)-1]
		}
		plan.Files = append(plan.Files, PlanFile{Zip: f.Name, Rel: rel, Kind: k})
	}
	hasLoadable := false
	for _, f := range plan.Files {
		if f.Kind == "plugin" || f.Kind == "patch" || f.Kind == "data" {
			hasLoadable = true
		}
	}
	if !hasLoadable {
		return nil, errors.New("no plugin files (.dll, .mpq or patch .json) were found in this zip")
	}
	sort.Slice(plan.Files, func(i, j int) bool { return plan.Files[i].Rel < plan.Files[j].Rel })
	plan.Name, plan.Version = nameFromZip(displayName)
	if (plan.Name == "" || strings.EqualFold(plan.Name, "plugin")) && firstDLL != "" {
		plan.Name = prettyName(firstDLL)
	}
	plan.ID = slug(plan.Name)
	if firstDLL != "" {
		plan.ID = slug(strings.TrimSuffix(firstDLL, path.Ext(firstDLL)))
	}
	if plan.ID == "" {
		plan.ID = "plugin"
	}
	return plan, nil
}

func containsFold(list []string, want string) bool {
	for _, s := range list {
		if strings.EqualFold(s, want) {
			return true
		}
	}
	return false
}

// markExisting fills PlanFile.Exists for a destination folder.
func markExisting(plan *InstallPlan, root string) {
	for i := range plan.Files {
		_, err := os.Stat(filepath.Join(root, filepath.FromSlash(plan.Files[i].Rel)))
		plan.Files[i].Exists = err == nil
	}
}

// topItem is what gets renamed to turn a file on or off: the file itself, or the whole folder for
// a folder-style MPQ ("plugins/x.mpq/data/...").
func topItem(rel string) string {
	segs := strings.Split(rel, "/")
	if len(segs) > 2 {
		return segs[0] + "/" + segs[1]
	}
	return rel
}

func toggleItems(files []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, f := range files {
		if kindOf(f) == "config" {
			continue
		}
		t := topItem(f)
		if !seen[t] {
			seen[t] = true
			out = append(out, t)
		}
	}
	return out
}

// ---------- installing ----------

// installPlugin copies the plan's files into root (a d2rloader folder). Existing config files are
// left alone so a player's plugin settings survive reinstalls. If store is set, a copy is also kept
// there (used to put mod-scoped plugins back after a mod update replaces the mod folder).
func installPlugin(zipPath string, plan *InstallPlan, root, store string, prev *InstalledPlugin) (*InstalledPlugin, error) {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return nil, err
	}
	defer zr.Close()
	byName := map[string]*zip.File{}
	for _, f := range zr.File {
		byName[f.Name] = f
	}
	// An earlier install that was switched off: switch its files back on first so paths line up.
	if prev != nil && !prev.Enabled {
		_ = setItemsEnabled(root, prev.Files, true)
	}
	var files []string
	for _, pf := range plan.Files {
		zf := byName[pf.Zip]
		if zf == nil {
			return nil, fmt.Errorf("%s vanished from the zip", pf.Zip)
		}
		dest := filepath.Join(root, filepath.FromSlash(pf.Rel))
		files = append(files, pf.Rel)
		if pf.Kind == "config" {
			if _, err := os.Stat(dest); err == nil {
				continue
			}
		}
		if err := writeZipFile(zf, dest); err != nil {
			return nil, err
		}
		if store != "" {
			if err := writeZipFile(zf, filepath.Join(store, filepath.FromSlash(pf.Rel))); err != nil {
				return nil, err
			}
		}
	}
	// Files the previous version had that this one doesn't: take them out (settings stay).
	if prev != nil {
		keep := map[string]bool{}
		for _, f := range files {
			keep[topItem(f)] = true
		}
		for _, t := range toggleItems(prev.Files) {
			if !keep[t] {
				os.RemoveAll(filepath.Join(root, filepath.FromSlash(t)))
			}
		}
	}
	return &InstalledPlugin{
		ID: plan.ID, Name: plan.Name, Version: plan.Version, Files: files, Enabled: true,
		InstalledAt: time.Now().Format(time.RFC3339),
	}, nil
}

func writeZipFile(zf *zip.File, dest string) error {
	if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
		return err
	}
	rc, err := zf.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	tmp := dest + ".installing"
	out, err := os.Create(tmp)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, rc); err != nil {
		out.Close()
		os.Remove(tmp)
		return fmt.Errorf("couldn't unpack %s: %w", zf.Name, err)
	}
	if err := out.Close(); err != nil {
		return err
	}
	os.RemoveAll(dest)
	os.Remove(dest + disabledExt)
	return os.Rename(tmp, dest)
}

// setItemsEnabled renames plugin files to/from "<name>.disabled". D2RLoader only loads .dll, .mpq
// and .json names, so a .disabled file is ignored but kept.
func setItemsEnabled(root string, files []string, on bool) error {
	for _, t := range toggleItems(files) {
		live := filepath.Join(root, filepath.FromSlash(t))
		off := live + disabledExt
		from, to := live, off
		if on {
			from, to = off, live
		}
		if _, err := os.Stat(from); err != nil {
			continue
		}
		if _, err := os.Stat(to); err == nil {
			os.RemoveAll(to)
		}
		if err := os.Rename(from, to); err != nil {
			return err
		}
	}
	return nil
}

// removeItems moves a plugin's files (not its settings) into trash, so nothing is lost for good.
func removeItems(root string, files []string, trash string) error {
	for _, t := range toggleItems(files) {
		for _, name := range []string{t, t + disabledExt} {
			src := filepath.Join(root, filepath.FromSlash(name))
			if _, err := os.Stat(src); err != nil {
				continue
			}
			dst := filepath.Join(trash, filepath.FromSlash(name))
			if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
				return err
			}
			if err := os.Rename(src, dst); err != nil {
				return err
			}
		}
	}
	return nil
}

// restoreModPlugins copies launcher-installed mod-scoped plugins back into a freshly installed mod.
func restoreModPlugins(reg *PluginRegistry, storeRoot, modD2RL string) error {
	for _, p := range reg.Plugins {
		if p.Scope != ScopeMod {
			continue
		}
		store := filepath.Join(storeRoot, p.ID)
		for _, rel := range p.Files {
			dest := filepath.Join(modD2RL, filepath.FromSlash(rel))
			if kindOf(rel) == "config" {
				if _, err := os.Stat(dest); err == nil {
					continue
				}
			}
			if err := copyFile(filepath.Join(store, filepath.FromSlash(rel)), dest); err != nil && !errors.Is(err, os.ErrNotExist) {
				return err
			}
		}
		if !p.Enabled {
			if err := setItemsEnabled(modD2RL, p.Files, false); err != nil {
				return err
			}
		}
	}
	return nil
}

// ---------- registry ----------

func loadRegistry(file string) *PluginRegistry {
	reg := &PluginRegistry{}
	if b, err := os.ReadFile(file); err == nil {
		_ = json.Unmarshal(b, reg)
	}
	return reg
}

func saveRegistry(file string, reg *PluginRegistry) error {
	if err := os.MkdirAll(filepath.Dir(file), 0o755); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(reg, "", "  ")
	tmp := file + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, file)
}

func (r *PluginRegistry) find(id, scope string) int {
	for i, p := range r.Plugins {
		if p.ID == id && p.Scope == scope {
			return i
		}
	}
	return -1
}

// ---------- listing ----------

type scanRoot struct {
	scope, origin, dir string
}

// listPlugins merges launcher-installed plugins with whatever else sits in the plugin folders.
func listPlugins(reg *PluginRegistry, globalRoot, modRoot string) []PluginView {
	var out []PluginView
	claimed := map[string]bool{} // scope + ":" + top item, lower-case
	for _, p := range reg.Plugins {
		root := globalRoot
		if p.Scope == ScopeMod {
			root = modRoot
		}
		for _, t := range toggleItems(p.Files) {
			claimed[p.Scope+":"+strings.ToLower(t)] = true
		}
		v := PluginView{
			Key: "t:" + p.Scope + ":" + p.ID, Name: p.Name, Version: p.Version, Author: p.Author,
			Description: p.Description, Kind: viewKind(p.Files), Scope: p.Scope, Origin: "launcher",
			Enabled: p.Enabled, Files: p.Files, CanToggle: true, CanRemove: true,
		}
		if dll := firstOfKind(p.Files, "plugin"); dll != "" && (v.Version == "" || v.Author == "" || v.Description == "") {
			fillFromDLL(&v, filepath.Join(root, filepath.FromSlash(dll)), p.Enabled)
		}
		out = append(out, v)
	}
	for _, sr := range []scanRoot{{ScopeGlobal, "found", globalRoot}, {ScopeMod, "mod", modRoot}} {
		if sr.dir == "" {
			continue
		}
		out = append(out, scanFolder(sr, claimed)...)
	}
	return out
}

func viewKind(files []string) string {
	if firstOfKind(files, "plugin") != "" {
		return "plugin"
	}
	if firstOfKind(files, "patch") != "" {
		return "patch"
	}
	return "data"
}

func firstOfKind(files []string, kind string) string {
	for _, f := range files {
		if kindOf(f) == kind {
			return f
		}
	}
	return ""
}

// scanFolder groups plugins\<stem>.dll with plugins\<stem>.mpq, and lists each patch .json.
func scanFolder(sr scanRoot, claimed map[string]bool) []PluginView {
	type group struct {
		stem    string
		files   []string
		enabled bool
		hasDLL  bool
	}
	groups := map[string]*group{}
	var order []string
	add := func(rel string) {
		live := strings.TrimSuffix(rel, disabledExt)
		if claimed[sr.scope+":"+strings.ToLower(live)] {
			return
		}
		base := path.Base(live)
		stem := strings.ToLower(strings.TrimSuffix(base, path.Ext(base)))
		key := path.Dir(live) + "/" + stem
		g := groups[key]
		if g == nil {
			g = &group{stem: strings.TrimSuffix(base, path.Ext(base))}
			groups[key] = g
			order = append(order, key)
		}
		g.files = append(g.files, live)
		if strings.EqualFold(path.Ext(live), ".dll") {
			g.hasDLL = true
			g.enabled = !strings.HasSuffix(rel, disabledExt)
		} else if !g.hasDLL {
			g.enabled = !strings.HasSuffix(rel, disabledExt)
		}
	}
	for _, sub := range []string{"plugins", "patches"} {
		entries, err := os.ReadDir(filepath.Join(sr.dir, sub))
		if err != nil {
			continue
		}
		for _, e := range entries {
			n := strings.ToLower(strings.TrimSuffix(e.Name(), disabledExt))
			ok := (sub == "plugins" && (strings.HasSuffix(n, ".dll") || strings.HasSuffix(n, ".mpq"))) ||
				(sub == "patches" && strings.HasSuffix(n, ".json"))
			if ok {
				add(sub + "/" + e.Name())
			}
		}
	}
	var out []PluginView
	for _, key := range order {
		g := groups[key]
		sort.Strings(g.files)
		v := PluginView{
			Key: "f:" + sr.scope + ":" + key, Name: prettyName(g.stem), Kind: viewKind(g.files),
			Scope: sr.scope, Origin: sr.origin, Enabled: g.enabled, Files: g.files,
			CanToggle: sr.origin == "found", CanRemove: sr.origin == "found",
		}
		if dll := firstOfKind(g.files, "plugin"); dll != "" {
			fillFromDLL(&v, filepath.Join(sr.dir, filepath.FromSlash(dll)), g.enabled)
		}
		out = append(out, v)
	}
	return out
}

func fillFromDLL(v *PluginView, dllPath string, enabled bool) {
	if !enabled {
		dllPath += disabledExt
	}
	info, ok := readPluginInfo(dllPath)
	if !ok {
		return
	}
	if info.Name != "" && (v.Origin != "launcher" || v.Name == "") {
		v.Name = info.Name
	}
	if v.Version == "" {
		v.Version = info.Version
	}
	if v.Author == "" {
		v.Author = info.Author
	}
	if v.Description == "" {
		v.Description = info.Description
	}
}

// ---------- reading PluginInfo out of a plugin DLL without running it ----------

type pluginInfo struct{ ID, Name, Version, Author, Description string }

// readPluginInfo finds the exported D2RLoaderGetPluginInfo, follows its "lea rax, [rip+x]" to the
// static PluginInfo record, and reads the string fields (id, name, version, author, description)
// in declaration order. It never loads or runs the DLL; anything unexpected just returns ok=false.
func readPluginInfo(file string) (info pluginInfo, ok bool) {
	defer func() {
		if recover() != nil {
			ok = false
		}
	}()
	f, err := pe.Open(file)
	if err != nil {
		return info, false
	}
	defer f.Close()
	oh, isPE64 := f.OptionalHeader.(*pe.OptionalHeader64)
	if !isPE64 || len(oh.DataDirectory) == 0 {
		return info, false
	}
	read := func(rva uint32, n int) []byte {
		for _, s := range f.Sections {
			size := s.VirtualSize
			if s.Size > size {
				size = s.Size
			}
			if rva >= s.VirtualAddress && rva < s.VirtualAddress+size {
				buf := make([]byte, n)
				m, _ := s.ReadAt(buf, int64(rva-s.VirtualAddress))
				return buf[:m]
			}
		}
		return nil
	}
	u32 := func(rva uint32) uint32 {
		b := read(rva, 4)
		if len(b) < 4 {
			panic("short read")
		}
		return binary.LittleEndian.Uint32(b)
	}
	cstr := func(rva uint32, max int) string {
		b := read(rva, max)
		if i := bytes.IndexByte(b, 0); i >= 0 {
			return string(b[:i])
		}
		return ""
	}
	exp := oh.DataDirectory[0]
	if exp.VirtualAddress == 0 {
		return info, false
	}
	nNames := u32(exp.VirtualAddress + 24)
	funcs, names, ords := u32(exp.VirtualAddress+28), u32(exp.VirtualAddress+32), u32(exp.VirtualAddress+36)
	var fn uint32
	for i := uint32(0); i < nNames && i < 4096; i++ {
		if cstr(u32(names+4*i), 64) == "D2RLoaderGetPluginInfo" {
			ob := read(ords+2*i, 2)
			fn = u32(funcs + 4*uint32(binary.LittleEndian.Uint16(ob)))
			break
		}
	}
	if fn == 0 {
		return info, false
	}
	var target uint32
	for hop := 0; hop < 3 && target == 0; hop++ {
		code := read(fn, 32)
		if len(code) >= 5 && code[0] == 0xE9 { // jmp (incremental-link thunk)
			fn = uint32(int64(fn) + 5 + int64(int32(binary.LittleEndian.Uint32(code[1:5]))))
			continue
		}
		for o := 0; o+7 <= len(code) && o < 24; o++ {
			if code[o] == 0x48 && code[o+1] == 0x8D && code[o+2] == 0x05 { // lea rax, [rip+disp32]
				target = uint32(int64(fn) + int64(o) + 7 + int64(int32(binary.LittleEndian.Uint32(code[o+3:o+7]))))
				break
			}
		}
		if target == 0 {
			break
		}
	}
	if target == 0 {
		return info, false
	}
	rec := read(target, 96)
	var strs []string
	started := false
	for off := 0; off+8 <= len(rec) && len(strs) < 5; off += 8 {
		v := binary.LittleEndian.Uint64(rec[off : off+8])
		switch {
		case v >= oh.ImageBase && v < oh.ImageBase+uint64(oh.SizeOfImage):
			s := cstr(uint32(v-oh.ImageBase), 512)
			if !printable(s) {
				return info, false
			}
			strs = append(strs, s)
			started = true
		case v == 0 && started:
			strs = append(strs, "")
		case started:
			off = len(rec) // flags reached
		}
	}
	if len(strs) < 3 || strs[1] == "" && strs[0] == "" {
		return info, false
	}
	for len(strs) < 5 {
		strs = append(strs, "")
	}
	info = pluginInfo{ID: strs[0], Name: strs[1], Version: strs[2], Author: strs[3], Description: strs[4]}
	if info.Name == "" {
		info.Name = info.ID
	}
	return info, true
}

func printable(s string) bool {
	for _, r := range s {
		if r < 0x20 && r != '\t' {
			return false
		}
		if r == unicode.ReplacementChar {
			return false
		}
	}
	return true
}
