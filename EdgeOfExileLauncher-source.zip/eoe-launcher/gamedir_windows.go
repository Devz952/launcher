//go:build windows

package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"golang.org/x/sys/windows/registry"
)

// Settings are per player, stored in %APPDATA%\<ModFolder>Launcher\settings.json.
type Settings struct {
	GameDir       string `json:"gameDir"`
	CloseOnLaunch *bool  `json:"closeOnLaunch,omitempty"` // nil = launcher.config.json default
	AutoInstall   bool   `json:"autoInstall"`             // install updates without asking
	LaunchOptions string `json:"launchOptions"`           // extra D2RLoader arguments the player typed
	Effects       *bool  `json:"effects,omitempty"`       // ember animation; nil = on
	KeepBackups   *int   `json:"keepBackups,omitempty"`   // nil = launcher.config.json default
}

func settingsPath(cfg Config) string {
	base, err := os.UserConfigDir()
	if err != nil {
		base = os.TempDir()
	}
	return filepath.Join(base, cfg.ModFolder+"Launcher", "settings.json")
}

func loadSettings(cfg Config) Settings {
	var s Settings
	if b, err := os.ReadFile(settingsPath(cfg)); err == nil {
		_ = json.Unmarshal(b, &s)
	}
	return s
}

func saveSettings(cfg Config, s Settings) {
	p := settingsPath(cfg)
	_ = os.MkdirAll(filepath.Dir(p), 0o755)
	if b, err := json.MarshalIndent(s, "", "  "); err == nil {
		_ = os.WriteFile(p, b, 0o644)
	}
}

func isGameDir(dir string) bool {
	if dir == "" {
		return false
	}
	_, err := os.Stat(filepath.Join(dir, "D2R.exe"))
	return err == nil
}

// findGameDir looks for Diablo II: Resurrected: the saved choice, the launcher's own folder (and its
// parents, in case it sits in mods\...), the Battle.net and Steam uninstall entries, then usual paths.
func findGameDir(saved, exeDir string) string {
	if isGameDir(saved) {
		return saved
	}
	for d, i := exeDir, 0; i < 3 && d != ""; d, i = filepath.Dir(d), i+1 {
		if isGameDir(d) {
			return d
		}
	}
	keys := []string{
		`SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Diablo II Resurrected`,
		`SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Diablo II Resurrected`,
		`SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 2536520`,
		`SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 2536520`,
	}
	for _, root := range []registry.Key{registry.LOCAL_MACHINE, registry.CURRENT_USER} {
		for _, k := range keys {
			if key, err := registry.OpenKey(root, k, registry.QUERY_VALUE); err == nil {
				loc, _, _ := key.GetStringValue("InstallLocation")
				key.Close()
				loc = strings.Trim(loc, `" `)
				if isGameDir(loc) {
					return loc
				}
			}
		}
	}
	var candidates []string
	for _, env := range []string{"ProgramFiles(x86)", "ProgramFiles"} {
		if pf := os.Getenv(env); pf != "" {
			candidates = append(candidates,
				filepath.Join(pf, "Diablo II Resurrected"),
				filepath.Join(pf, "Steam", "steamapps", "common", "Diablo II Resurrected"))
		}
	}
	for _, drive := range []string{"C", "D", "E", "F"} {
		candidates = append(candidates,
			drive+`:\Games\Diablo II Resurrected`,
			drive+`:\Battle.net\Games\Diablo II Resurrected`,
			drive+`:\SteamLibrary\steamapps\common\Diablo II Resurrected`)
	}
	for _, c := range candidates {
		if isGameDir(c) {
			return c
		}
	}
	return ""
}
