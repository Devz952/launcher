# Zips your installed mod folder into a release the launcher can install, and (if the GitHub CLI
# is installed and signed in) publishes it as a GitHub Release.
#   powershell -ExecutionPolicy Bypass -File make-release.ps1 -Version 1.5.0
#   powershell -ExecutionPolicy Bypass -File make-release.ps1 -Version 1.5.0 -Notes notes.md
param(
    [Parameter(Mandatory)][string]$Version,                          # e.g. 1.5.0  (tag becomes v1.5.0)
    [string]$Game = "C:\Program Files (x86)\Diablo II Resurrected",  # your D2R folder
    [string]$Mod = "EdgeOfExile",                                    # folder under <Game>\mods
    [string]$Notes = "",                                             # optional markdown file for patch notes
    [string]$Repo = ""                                               # owner/repo (needed when not run inside the repo)
)
$ErrorActionPreference = 'Stop'
$Version = $Version.TrimStart('v', 'V')
$src = Join-Path $Game "mods\$Mod"
if (-not (Test-Path $src)) { throw "$src not found" }

# Stage a clean copy so launcher-only files never end up in the release.
$work = Join-Path $env:TEMP "eoe-release"
Remove-Item -Recurse -Force $work -ErrorAction SilentlyContinue
New-Item -ItemType Directory $work | Out-Null
Copy-Item $src (Join-Path $work $Mod) -Recurse
Remove-Item (Join-Path $work "$Mod\.launcher-version") -ErrorAction SilentlyContinue

# Keep D2RLoader's metadata version in step with the release tag.
$meta = Join-Path $work "$Mod\d2rloader\metadata.json"
if (Test-Path $meta) {
    $json = Get-Content $meta -Raw | ConvertFrom-Json
    if ($json.metadata) { $json.metadata.modVersion = $Version; $json | ConvertTo-Json -Depth 10 | Set-Content $meta -Encoding UTF8 }
}

$zip = Join-Path $PSScriptRoot "$Mod-$Version.zip"
Remove-Item $zip -ErrorAction SilentlyContinue
tar -a -c -f $zip -C $work $Mod          # Windows 10+ tar writes standard zips quickly
if ($LASTEXITCODE -ne 0) { Compress-Archive -Path (Join-Path $work $Mod) -DestinationPath $zip -Force }
Remove-Item -Recurse -Force $work
Write-Output "release zip: $zip ($([math]::Round((Get-Item $zip).Length / 1MB, 1)) MB)"

if (Get-Command gh -ErrorAction SilentlyContinue) {
    $notesArgs = if ($Notes) { @('--notes-file', $Notes) } else { @('--generate-notes') }
    $repoArgs = if ($Repo) { @('--repo', $Repo) } else { @() }
    gh release create "v$Version" $zip --title "Edge of Exile v$Version" @notesArgs @repoArgs
} else {
    Write-Output "Now create a release tagged v$Version on GitHub and attach that zip."
}
