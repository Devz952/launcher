//go:build !windows

package main

import "fmt"

// The launcher is Windows-only; this stub lets the shared update logic build and test elsewhere.
func main() { fmt.Println("Edge of Exile launcher " + launcherVersion + " runs on Windows.") }
