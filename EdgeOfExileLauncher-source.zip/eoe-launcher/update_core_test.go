package main

import (
	"archive/zip"
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func writeZip(t *testing.T, path string, files map[string]string) {
	t.Helper()
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	zw := zip.NewWriter(f)
	for name, body := range files {
		w, err := zw.Create(name)
		if err != nil {
			t.Fatal(err)
		}
		w.Write([]byte(body))
	}
	zw.Close()
	f.Close()
}

func read(t *testing.T, p string) string {
	t.Helper()
	b, err := os.ReadFile(p)
	if err != nil {
		t.Fatalf("read %s: %v", p, err)
	}
	return string(b)
}

func TestCompareVersions(t *testing.T) {
	cases := []struct {
		a, b string
		want int
	}{
		{"v1.5.0", "1.4.0", 1}, {"1.10.0", "1.9.9", 1}, {"1.4", "1.4.0", 0}, {"v2.0.0-beta", "2.0.0", -1},
		{"1.4.0", "v1.4.0", 0}, {"0.9", "1.0", -1},
	}
	for _, c := range cases {
		if got := compareVersions(c.a, c.b); got != c.want {
			t.Errorf("compare(%q,%q)=%d want %d", c.a, c.b, got, c.want)
		}
	}
}

func TestNormalizeRepo(t *testing.T) {
	for in, want := range map[string]string{
		"me/edge-of-exile": "me/edge-of-exile", "https://github.com/me/eoe": "me/eoe",
		"https://github.com/me/eoe.git": "me/eoe", "github.com/me/eoe/": "me/eoe", "OWNER/REPO": "", "": "",
	} {
		if got := normalizeRepo(in); got != want {
			t.Errorf("normalizeRepo(%q)=%q want %q", in, got, want)
		}
	}
}

// Every way a release might be zipped should land as mods\EdgeOfExile\<contents>.
func TestExtractLayouts(t *testing.T) {
	content := map[string]string{
		"EdgeOfExile.mpq/modinfo.json":          `{"name":"EdgeOfExile"}`,
		"EdgeOfExile.mpq/data/global/x.txt":     "x",
		"modinfo.json":                          `{"name":"EdgeOfExile"}`,
		"d2rloader/plugins/eoe-core.dll":        "dll",
		"d2rloader/config/d2rloader.toml":       "new",
	}
	layouts := map[string]string{"flat": "", "folder": "EdgeOfExile/", "mods": "mods/EdgeOfExile/", "versioned": "EdgeOfExile-v1.5.0/"}
	for name, prefix := range layouts {
		t.Run(name, func(t *testing.T) {
			dir := t.TempDir()
			files := map[string]string{}
			for k, v := range content {
				files[prefix+k] = v
			}
			zp := filepath.Join(dir, "r.zip")
			writeZip(t, zp, files)
			dest := filepath.Join(dir, "out")
			if err := extractZip(zp, dest, func(int, int) {}); err != nil {
				t.Fatal(err)
			}
			if read(t, filepath.Join(dest, "d2rloader", "plugins", "eoe-core.dll")) != "dll" {
				t.Fatal("plugin not at mod root")
			}
			if read(t, filepath.Join(dest, "EdgeOfExile.mpq", "data", "global", "x.txt")) != "x" {
				t.Fatal("mpq data missing")
			}
		})
	}
}

func TestExtractRejectsUnsafeAndNonMods(t *testing.T) {
	dir := t.TempDir()
	zp := filepath.Join(dir, "evil.zip")
	writeZip(t, zp, map[string]string{"../../evil.txt": "x", "modinfo.json": "{}"})
	if err := extractZip(zp, filepath.Join(dir, "o1"), func(int, int) {}); err == nil || !strings.Contains(err.Error(), "unsafe") {
		t.Fatalf("want unsafe-path error, got %v", err)
	}
	zp2 := filepath.Join(dir, "notmod.zip")
	writeZip(t, zp2, map[string]string{"readme.txt": "hi", "pics/a.png": "p"})
	if err := extractZip(zp2, filepath.Join(dir, "o2"), func(int, int) {}); err == nil {
		t.Fatal("want error for a zip that isn't a mod")
	}
}

func TestInstallPreservesSettingsAndBacksUp(t *testing.T) {
	game := t.TempDir()
	mod := filepath.Join(game, "mods", "EdgeOfExile")
	os.MkdirAll(filepath.Join(mod, "d2rloader", "config"), 0o755)
	os.WriteFile(filepath.Join(mod, "modinfo.json"), []byte("{}"), 0o644)
	os.WriteFile(filepath.Join(mod, "d2rloader", "config", "d2rloader.toml"), []byte("players-edit"), 0o644)
	os.WriteFile(filepath.Join(mod, versionFile), []byte("1.4.0\n"), 0o644)
	os.WriteFile(filepath.Join(mod, "old-only.txt"), []byte("stale"), 0o644)

	staging := filepath.Join(game, "EdgeOfExileLauncher", "staging")
	zp := filepath.Join(game, "r.zip")
	writeZip(t, zp, map[string]string{
		"EdgeOfExile/modinfo.json":                    "{}",
		"EdgeOfExile/d2rloader/config/d2rloader.toml": "release-default",
		"EdgeOfExile/d2rloader/plugins/new.dll":       "dll",
	})
	if err := extractZip(zp, staging, func(int, int) {}); err != nil {
		t.Fatal(err)
	}
	if err := preserveFiles(mod, staging, []string{"d2rloader/config"}); err != nil {
		t.Fatal(err)
	}
	os.WriteFile(filepath.Join(staging, versionFile), []byte("1.5.0\n"), 0o644)
	backups := filepath.Join(game, "EdgeOfExileLauncher", "backups")
	if err := swapIn(mod, staging, backups, "1.4.0", 2); err != nil {
		t.Fatal(err)
	}
	if got := read(t, filepath.Join(mod, "d2rloader", "config", "d2rloader.toml")); got != "players-edit" {
		t.Fatalf("player config not kept: %q", got)
	}
	if _, err := os.Stat(filepath.Join(mod, "old-only.txt")); !os.IsNotExist(err) {
		t.Fatal("stale file from old version survived")
	}
	if ok, v := installedVersion(mod); !ok || v != "1.5.0" {
		t.Fatalf("installedVersion = %v %q", ok, v)
	}
	entries, _ := os.ReadDir(backups)
	if len(entries) != 1 || !strings.HasPrefix(entries[0].Name(), "EdgeOfExile-1.4.0-") {
		t.Fatalf("backup not made: %v", entries)
	}
}

func TestPruneBackupsKeepsNewest(t *testing.T) {
	dir := t.TempDir()
	for _, n := range []string{"EdgeOfExile-1.1-20260101-000000", "EdgeOfExile-1.3-20260301-000000", "EdgeOfExile-1.2-20260201-000000", "Other-1-20250101-000000"} {
		os.MkdirAll(filepath.Join(dir, n), 0o755)
	}
	pruneBackups(dir, "EdgeOfExile-", 2)
	var left []string
	es, _ := os.ReadDir(dir)
	for _, e := range es {
		left = append(left, e.Name())
	}
	if strings.Join(left, ",") != "EdgeOfExile-1.2-20260201-000000,EdgeOfExile-1.3-20260301-000000,Other-1-20250101-000000" {
		t.Fatalf("left %v", left)
	}
}

func TestInstalledVersionFromMetadata(t *testing.T) {
	mod := t.TempDir()
	os.MkdirAll(filepath.Join(mod, "d2rloader"), 0o755)
	os.WriteFile(filepath.Join(mod, "d2rloader", "metadata.json"), []byte(`{"schemaVersion":1,"metadata":{"modVersion":"1.3.2"}}`), 0o644)
	if ok, v := installedVersion(mod); !ok || v != "1.3.2" {
		t.Fatalf("got %v %q", ok, v)
	}
	if ok, _ := installedVersion(filepath.Join(mod, "missing")); ok {
		t.Fatal("missing folder reported installed")
	}
}

func TestDownloadAndPickAsset(t *testing.T) {
	body := strings.Repeat("ember", 200000)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.Write([]byte(body)) }))
	defer srv.Close()
	rel := &Release{Tag: "v1.5.0", Assets: []Asset{{Name: "notes.txt"}, {Name: "EdgeOfExile-1.5.0.zip", URL: srv.URL, Size: int64(len(body))}}}
	a, err := pickAsset(rel, "")
	if err != nil || a.Name != "EdgeOfExile-1.5.0.zip" {
		t.Fatalf("pickAsset: %v %v", a, err)
	}
	dest := filepath.Join(t.TempDir(), "r.zip")
	var last int64
	if err := downloadFile(context.Background(), a.URL, dest, a.Size, func(d, total int64) { last = d }); err != nil {
		t.Fatal(err)
	}
	if last != int64(len(body)) || read(t, dest) != body {
		t.Fatal("download mismatch")
	}
	if _, err := pickAsset(&Release{Tag: "v1"}, ""); err == nil {
		t.Fatal("want error with no zip")
	}
}

func TestSplitArgs(t *testing.T) {
	got := strings.Join(splitArgs(` -w  -ns "-name x" -txt`), "|")
	if got != `-w|-ns|-name x|-txt` {
		t.Fatalf("got %q", got)
	}
	if len(splitArgs("   ")) != 0 {
		t.Fatal("blank should give no args")
	}
}

func TestListBackupsAndRollback(t *testing.T) {
	game := t.TempDir()
	mod := filepath.Join(game, "mods", "EdgeOfExile")
	backups := filepath.Join(game, "EdgeOfExileLauncher", "backups")
	mk := func(dir, ver, cfg string) {
		os.MkdirAll(filepath.Join(dir, "d2rloader", "config"), 0o755)
		os.WriteFile(filepath.Join(dir, "modinfo.json"), []byte("{}"), 0o644)
		os.WriteFile(filepath.Join(dir, versionFile), []byte(ver), 0o644)
		os.WriteFile(filepath.Join(dir, "d2rloader", "config", "d2rloader.toml"), []byte(cfg), 0o644)
	}
	mk(mod, "1.5.0", "current-settings")
	mk(filepath.Join(backups, "EdgeOfExile-1.4.0-20261001-120000"), "1.4.0", "old-settings")
	mk(filepath.Join(backups, "EdgeOfExile-1.3.0-beta-20260901-120000"), "1.3.0-beta", "older")

	list := listBackups(backups, "EdgeOfExile")
	if len(list) != 2 || list[0].Version != "1.4.0" || list[1].Version != "1.3.0-beta" {
		t.Fatalf("list = %+v", list)
	}
	if err := rollback(mod, backups, list[0].Name, "1.5.0", []string{"d2rloader/config"}, 2); err != nil {
		t.Fatal(err)
	}
	if _, v := installedVersion(mod); v != "1.4.0" {
		t.Fatalf("after rollback version = %q", v)
	}
	if got := read(t, filepath.Join(mod, "d2rloader", "config", "d2rloader.toml")); got != "current-settings" {
		t.Fatalf("settings not carried over: %q", got)
	}
	after := listBackups(backups, "EdgeOfExile")
	if len(after) != 2 || after[0].Version != "1.5.0" {
		t.Fatalf("1.5.0 should now be the newest backup: %+v", after)
	}
	if err := rollback(mod, backups, "../../evil", "1.4.0", nil, 2); err == nil {
		t.Fatal("want error for a bad backup name")
	}
}
