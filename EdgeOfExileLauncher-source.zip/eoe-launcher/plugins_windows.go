//go:build windows

package main

import (
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Plugin manager bindings for the Plugins tab. Shared plugins go to <game>\d2rloader; plugins for
// this mod only go to <game>\mods\<ModFolder>\d2rloader and are put back after every mod update.

func (a *App) globalD2RL() string { return filepath.Join(a.gameDir, "d2rloader") }
func (a *App) modD2RL() string    { return filepath.Join(a.modDir(), "d2rloader") }
func (a *App) registryPath() string {
	return filepath.Join(a.workDir(), "plugins.json")
}
func (a *App) pluginStore() string { return filepath.Join(a.workDir(), "plugin-store") }

func (a *App) scopeRoot(scope string) string {
	if scope == ScopeMod {
		return a.modD2RL()
	}
	return a.globalD2RL()
}

// pluginGuard returns a result map when plugins can't be changed right now.
func (a *App) pluginGuard() map[string]any {
	if !isGameDir(a.gameDir) {
		return map[string]any{"ok": false, "error": "Set your game folder in Settings first."}
	}
	if p := runningProcess("D2R.exe", "D2RLoader.exe"); p != "" {
		return map[string]any{"ok": false, "gameRunning": true, "error": p + " is still running"}
	}
	for _, d := range []string{a.workDir(), a.globalD2RL()} {
		if err := os.MkdirAll(d, 0o755); err != nil {
			if isAccessDenied(err) {
				return map[string]any{"ok": false, "needsAdmin": true}
			}
			return map[string]any{"ok": false, "error": err.Error()}
		}
		probe := filepath.Join(d, ".write-test")
		if err := os.WriteFile(probe, []byte("ok"), 0o644); err != nil {
			if isAccessDenied(err) {
				return map[string]any{"ok": false, "needsAdmin": true}
			}
			return map[string]any{"ok": false, "error": err.Error()}
		}
		os.Remove(probe)
	}
	return nil
}

func (a *App) pluginList() map[string]any {
	if !isGameDir(a.gameDir) {
		return map[string]any{"items": []PluginView{}, "gameDirOk": false}
	}
	reg := loadRegistry(a.registryPath())
	modRoot := ""
	if looksLikeMod(a.modDir()) {
		modRoot = a.modD2RL()
	}
	items := listPlugins(reg, a.globalD2RL(), modRoot)
	if items == nil {
		items = []PluginView{}
	}
	return map[string]any{"items": items, "gameDirOk": true, "modInstalled": modRoot != ""}
}

func (a *App) bindPlugins() {
	w := a.w

	w.Bind("listPlugins", func() map[string]any { return a.pluginList() })

	// The file picker is modal, so it runs from the message loop; the result arrives as "pluginPlan".
	w.Bind("pickPluginZip", func() {
		w.Dispatch(func() {
			start := filepath.Join(os.Getenv("USERPROFILE"), "Downloads")
			file, err := pickFile(a.hwnd, "Choose a D2RLoader plugin (.zip)", start, "Plugin zip", "*.zip")
			switch {
			case err != nil:
				a.emit("pluginPlan", map[string]any{"error": err.Error()})
			case file == "":
				a.emit("pluginPlan", map[string]any{"cancelled": true})
			default:
				a.emit("pluginPlan", a.planFor(file))
			}
		})
	})

	w.Bind("installPlugin", func(file, scope string) {
		go func() { a.emit("pluginInstalled", a.doInstallPlugin(file, scope)) }()
	})

	w.Bind("setPluginEnabled", func(key string, on bool) map[string]any {
		if g := a.pluginGuard(); g != nil {
			return g
		}
		return a.changePlugin(key, func(root string, files []string, reg *PluginRegistry, idx int) error {
			if err := setItemsEnabled(root, files, on); err != nil {
				return err
			}
			if idx >= 0 {
				reg.Plugins[idx].Enabled = on
			}
			return nil
		})
	})

	w.Bind("removePlugin", func(key string) map[string]any {
		if g := a.pluginGuard(); g != nil {
			return g
		}
		trash := filepath.Join(a.workDir(), "removed-plugins", time.Now().Format("20060102-150405"))
		return a.changePlugin(key, func(root string, files []string, reg *PluginRegistry, idx int) error {
			if err := removeItems(root, files, trash); err != nil {
				return err
			}
			if idx >= 0 {
				os.RemoveAll(filepath.Join(a.pluginStore(), reg.Plugins[idx].ID))
				reg.Plugins = append(reg.Plugins[:idx], reg.Plugins[idx+1:]...)
			}
			return nil
		})
	})

	w.Bind("openPluginsFolder", func(scope string) {
		d := filepath.Join(a.scopeRoot(scope), "plugins")
		if _, err := os.Stat(d); err == nil {
			shellOpen(a.hwnd, "open", d, "", "")
		} else if _, err := os.Stat(a.scopeRoot(scope)); err == nil {
			shellOpen(a.hwnd, "open", a.scopeRoot(scope), "", "")
		}
	})
}

func (a *App) planFor(file string) map[string]any {
	plan, err := planPluginZip(file, filepath.Base(file))
	if err != nil {
		return map[string]any{"error": err.Error(), "file": filepath.Base(file)}
	}
	markExisting(plan, a.scopeRoot(plan.SuggestedScope))
	reg := loadRegistry(a.registryPath())
	upgrade := ""
	if i := reg.find(plan.ID, plan.SuggestedScope); i >= 0 {
		upgrade = reg.Plugins[i].Version
		if upgrade == "" {
			upgrade = "installed"
		}
	}
	return map[string]any{
		"file": file, "fileName": filepath.Base(file), "plan": plan, "upgradeFrom": upgrade,
		"modInstalled": looksLikeMod(a.modDir()), "modName": a.cfg.ModName,
	}
}

func (a *App) doInstallPlugin(file, scope string) map[string]any {
	if !strings.EqualFold(filepath.Ext(file), ".zip") {
		return map[string]any{"ok": false, "error": "pick a .zip file"}
	}
	if scope != ScopeMod {
		scope = ScopeGlobal
	}
	if g := a.pluginGuard(); g != nil {
		return g
	}
	if scope == ScopeMod && !looksLikeMod(a.modDir()) {
		return map[string]any{"ok": false, "error": a.cfg.ModName + " isn't installed yet, so the plugin can't go into its folder."}
	}
	plan, err := planPluginZip(file, filepath.Base(file))
	if err != nil {
		return map[string]any{"ok": false, "error": err.Error()}
	}
	reg := loadRegistry(a.registryPath())
	idx := reg.find(plan.ID, scope)
	var prev *InstalledPlugin
	if idx >= 0 {
		p := reg.Plugins[idx]
		prev = &p
	}
	store := ""
	if scope == ScopeMod {
		store = filepath.Join(a.pluginStore(), plan.ID)
		os.RemoveAll(store)
	}
	inst, err := installPlugin(file, plan, a.scopeRoot(scope), store, prev)
	if err != nil {
		if isAccessDenied(err) {
			return map[string]any{"ok": false, "needsAdmin": true}
		}
		return map[string]any{"ok": false, "error": err.Error()}
	}
	inst.Scope = scope
	inst.Source = filepath.Base(file)
	if dll := firstOfKind(inst.Files, "plugin"); dll != "" {
		if info, ok := readPluginInfo(filepath.Join(a.scopeRoot(scope), filepath.FromSlash(dll))); ok {
			if info.Version != "" {
				inst.Version = info.Version
			}
			inst.Author, inst.Description = info.Author, info.Description
			if info.Name != "" && !strings.Contains(inst.Source, info.Name) && inst.Name == strings.TrimSuffix(inst.Source, filepath.Ext(inst.Source)) {
				inst.Name = info.Name
			}
		}
	}
	if idx >= 0 {
		reg.Plugins[idx] = *inst
	} else {
		reg.Plugins = append(reg.Plugins, *inst)
	}
	if err := saveRegistry(a.registryPath(), reg); err != nil {
		return map[string]any{"ok": false, "error": "installed, but couldn't record it: " + err.Error()}
	}
	return map[string]any{"ok": true, "name": inst.Name, "version": inst.Version, "upgraded": prev != nil}
}

// changePlugin finds the plugin behind a list key ("t:<scope>:<id>" for ones the launcher
// installed, "f:<scope>:<dir>/<stem>" for ones found in the folders) and applies fn to its files.
func (a *App) changePlugin(key string, fn func(root string, files []string, reg *PluginRegistry, idx int) error) map[string]any {
	reg := loadRegistry(a.registryPath())
	parts := strings.SplitN(key, ":", 3)
	if len(parts) != 3 || (parts[1] != ScopeGlobal && parts[1] != ScopeMod) {
		return map[string]any{"ok": false, "error": "unknown plugin"}
	}
	scope := parts[1]
	root := a.scopeRoot(scope)
	var files []string
	idx := -1
	switch parts[0] {
	case "t":
		idx = reg.find(parts[2], scope)
		if idx < 0 {
			return map[string]any{"ok": false, "error": "that plugin is no longer installed"}
		}
		files = reg.Plugins[idx].Files
	case "f":
		if scope != ScopeGlobal {
			return map[string]any{"ok": false, "error": "plugins included with the mod can't be changed here"}
		}
		modRoot := ""
		if looksLikeMod(a.modDir()) {
			modRoot = a.modD2RL()
		}
		for _, v := range listPlugins(reg, a.globalD2RL(), modRoot) {
			if v.Key == key {
				files = v.Files
			}
		}
		if files == nil {
			return map[string]any{"ok": false, "error": "that plugin is no longer there"}
		}
	default:
		return map[string]any{"ok": false, "error": "unknown plugin"}
	}
	if err := fn(root, files, reg, idx); err != nil {
		if isAccessDenied(err) {
			return map[string]any{"ok": false, "needsAdmin": true}
		}
		return map[string]any{"ok": false, "error": err.Error()}
	}
	if idx >= 0 || parts[0] == "t" {
		if err := saveRegistry(a.registryPath(), reg); err != nil {
			return map[string]any{"ok": false, "error": err.Error()}
		}
	}
	return map[string]any{"ok": true}
}

// afterModSwap puts this mod's launcher-installed plugins back after an update or rollback.
func (a *App) afterModSwap() error {
	reg := loadRegistry(a.registryPath())
	return restoreModPlugins(reg, a.pluginStore(), a.modD2RL())
}

