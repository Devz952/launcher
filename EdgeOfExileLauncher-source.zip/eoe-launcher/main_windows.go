//go:build windows

package main

import (
	"context"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"time"

	webview "github.com/jchv/go-webview2"
	"golang.org/x/sys/windows"
)

//go:embed ui
var uiFS embed.FS

const (
	winW, winH = 960, 640
	iconID     = 2 // rsrc puts the manifest at 1 and the icon group at 2
)

type App struct {
	cfg        Config
	settings   Settings
	exePath    string
	exeDir     string
	gameDir    string
	autoUpdate bool

	w    webview.WebView
	hwnd uintptr

	mu     sync.Mutex
	busy   bool
	latest *Release
	asset  *Asset
}

func main() {
	enableDPIAwareness()
	exe, _ := os.Executable()
	exe, _ = filepath.EvalSymlinks(exe)
	app := &App{exePath: exe, exeDir: filepath.Dir(exe)}
	app.cfg = loadConfig(app.exeDir)
	app.autoUpdate = slices.Contains(os.Args[1:], "--update")

	if !singleInstance(`Local\`+app.cfg.ModFolder+"Launcher", app.autoUpdate) {
		focusExistingWindow(app.cfg.ModName)
		return
	}
	app.settings = loadSettings(app.cfg)
	app.gameDir = findGameDir(app.settings.GameDir, app.exeDir)

	// The UI is served from memory on a random loopback port.
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		messageBox(0, app.cfg.ModName, "Couldn't start the launcher: "+err.Error(), 0x10)
		return
	}
	sub, _ := fs.Sub(uiFS, "ui")
	files := http.FileServer(http.FS(sub))
	go http.Serve(ln, http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		rw.Header().Set("Cache-Control", "no-store")
		files.ServeHTTP(rw, r)
	}))

	dataDir := filepath.Join(os.Getenv("LOCALAPPDATA"), app.cfg.ModFolder+"Launcher", "WebView2")
	w := webview.NewWithOptions(webview.WebViewOptions{
		Debug:     os.Getenv("EOE_LAUNCHER_DEBUG") != "",
		DataPath:  dataDir,
		AutoFocus: true,
		WindowOptions: webview.WindowOptions{
			Title: app.cfg.ModName, Width: winW, Height: winH, IconId: iconID, Center: true,
		},
	})
	if w == nil {
		const msg = "This launcher needs the Microsoft Edge WebView2 Runtime (it ships with Windows 10 and 11, " +
			"but it can be missing on older or trimmed-down systems).\n\nOpen the download page now?"
		if messageBox(0, app.cfg.ModName, msg, 0x04|0x30) == 6 { // MB_YESNO|MB_ICONWARNING → IDYES
			shellOpen(0, "open", "https://developer.microsoft.com/microsoft-edge/webview2/", "", "")
		}
		return
	}
	defer w.Destroy()
	app.w = w
	app.hwnd = uintptr(w.Window())
	darkTitleBar(app.hwnd)
	dpi := windowDPI(app.hwnd)
	w.SetSize(winW*dpi/96, winH*dpi/96, webview.HintFixed)
	centerWindow(app.hwnd)

	app.bind()
	app.bindPlugins()
	w.Navigate("http://" + ln.Addr().String() + "/index.html")
	w.Run()
}

// emit sends an event to the page (window.__emit) from any goroutine.
func (a *App) emit(event string, data any) {
	b, _ := json.Marshal(data)
	ev, _ := json.Marshal(event)
	a.w.Dispatch(func() { a.w.Eval("window.__emit && window.__emit(" + string(ev) + "," + string(b) + ")") })
}

func (a *App) modDir() string { return filepath.Join(a.gameDir, "mods", a.cfg.ModFolder) }

// workDir holds staging and backups. It sits inside the game folder so moving folders is a cheap
// rename on the same drive, but outside mods\ so D2RLoader never lists it as a mod.
func (a *App) workDir() string { return filepath.Join(a.gameDir, a.cfg.ModFolder+"Launcher") }

func (a *App) bind() {
	w := a.w

	w.Bind("getState", func() map[string]any {
		installed, ver := false, ""
		loader := false
		if isGameDir(a.gameDir) {
			installed, ver = installedVersion(a.modDir())
			_, err := os.Stat(filepath.Join(a.gameDir, "D2RLoader.exe"))
			loader = err == nil
		}
		auto := a.autoUpdate
		a.autoUpdate = false
		return map[string]any{
			"launcherVersion":  launcherVersion,
			"modName":          a.cfg.ModName,
			"gameDir":          a.gameDir,
			"gameDirOk":        isGameDir(a.gameDir),
			"loaderFound":      loader,
			"modInstalled":     installed,
			"installedVersion": ver,
			"repoConfigured":   a.cfg.GitHubRepo != "",
			"repoUrl":          repoURL(a.cfg.GitHubRepo),
			"autoUpdate":       auto,
			"settings":         a.settingsView(),
		}
	})

	w.Bind("saveSettings", func(in settingsIn) map[string]any {
		a.mu.Lock()
		defer a.mu.Unlock()
		close := in.CloseOnLaunch
		effects := in.Effects
		keep := min(max(in.KeepBackups, 0), 5)
		opts := strings.TrimSpace(in.LaunchOptions)
		if len(opts) > 300 {
			opts = opts[:300]
		}
		a.settings.CloseOnLaunch = &close
		a.settings.Effects = &effects
		a.settings.KeepBackups = &keep
		a.settings.AutoInstall = in.AutoInstall
		a.settings.LaunchOptions = opts
		saveSettings(a.cfg, a.settings)
		return a.settingsViewLocked()
	})

	w.Bind("rollback", func(name string) {
		a.mu.Lock()
		if a.busy {
			a.mu.Unlock()
			return
		}
		a.busy = true
		a.mu.Unlock()
		go func() {
			res := a.runRollback(name)
			a.mu.Lock()
			a.busy = false
			a.mu.Unlock()
			a.emit("rollbackDone", res)
		}()
	})

	w.Bind("openBackupsFolder", func() {
		d := filepath.Join(a.workDir(), "backups")
		if _, err := os.Stat(d); err == nil {
			shellOpen(a.hwnd, "open", d, "", "")
		}
	})

	w.Bind("checkForUpdates", func() {
		go a.checkForUpdates()
	})

	w.Bind("startUpdate", func() {
		a.mu.Lock()
		if a.busy {
			a.mu.Unlock()
			return
		}
		a.busy = true
		a.mu.Unlock()
		go func() {
			res := a.runUpdate()
			a.mu.Lock()
			a.busy = false
			a.mu.Unlock()
			a.emit("updateDone", res)
		}()
	})

	w.Bind("play", func() map[string]any {
		loader := filepath.Join(a.gameDir, "D2RLoader.exe")
		if _, err := os.Stat(loader); err != nil {
			return map[string]any{"ok": false, "error": "D2RLoader.exe isn't in " + a.gameDir}
		}
		a.mu.Lock()
		all := append(append([]string{}, a.cfg.LaunchArgs...), splitArgs(a.settings.LaunchOptions)...)
		closing := a.closeOnLaunch()
		a.mu.Unlock()
		args := make([]string, 0, len(all))
		for _, s := range all {
			if strings.ContainsAny(s, " \t") {
				s = `"` + s + `"`
			}
			args = append(args, s)
		}
		// ShellExecute (not CreateProcess) so a loader that needs elevation gets its normal UAC prompt.
		if err := shellOpen(a.hwnd, "open", loader, strings.Join(args, " "), a.gameDir); err != nil {
			if isCancelled(err) {
				return map[string]any{"ok": false, "error": "Launch was cancelled."}
			}
			return map[string]any{"ok": false, "error": err.Error()}
		}
		if closing {
			go func() {
				time.Sleep(900 * time.Millisecond)
				a.w.Dispatch(func() { a.w.Terminate() })
			}()
		}
		return map[string]any{"ok": true, "closing": closing}
	})

	// The folder picker is modal, so it runs from the message loop rather than inside the WebView2
	// message handler; the result comes back as a "folderChosen" event.
	w.Bind("chooseGameDir", func() {
		w.Dispatch(func() { a.emit("folderChosen", a.chooseGameDir()) })
	})

	w.Bind("openUrl", func(url string) {
		if strings.HasPrefix(url, "https://") {
			shellOpen(a.hwnd, "open", url, "", "")
		}
	})

	w.Bind("openModFolder", func() {
		if d := a.modDir(); looksLikeMod(d) {
			shellOpen(a.hwnd, "open", d, "", "")
		}
	})

	// resume=true continues the pending update after the restart.
	w.Bind("restartAsAdmin", func(resume bool) {
		args := ""
		if resume {
			args = "--update"
		}
		if err := shellOpen(a.hwnd, "runas", a.exePath, args, a.exeDir); err == nil {
			a.w.Terminate()
		}
	})
}

func (a *App) chooseGameDir() map[string]any {
	a.mu.Lock()
	busy := a.busy
	a.mu.Unlock()
	if busy {
		return map[string]any{"changed": false}
	}
	start := a.gameDir
	if start == "" {
		start = os.Getenv("ProgramFiles(x86)")
	}
	dir, err := pickFolder(a.hwnd, "Choose your Diablo II: Resurrected folder", start)
	if err != nil {
		return map[string]any{"error": err.Error()}
	}
	if dir == "" {
		return map[string]any{"changed": false}
	}
	if !isGameDir(dir) {
		if p := filepath.Dir(dir); isGameDir(p) { // picked a subfolder such as mods\
			dir = p
		} else {
			return map[string]any{"error": "D2R.exe isn't in " + dir + ". Pick the folder that contains it."}
		}
	}
	a.mu.Lock()
	a.gameDir = dir
	a.settings.GameDir = dir
	saveSettings(a.cfg, a.settings)
	a.mu.Unlock()
	return map[string]any{"changed": true, "gameDir": dir}
}

func (a *App) checkForUpdates() {
	rel, err := fetchLatestRelease(context.Background(), a.cfg.GitHubRepo)
	if err != nil {
		a.emit("check", map[string]any{"error": err.Error()})
		return
	}
	asset, err := pickAsset(rel, a.cfg.AssetName)
	if err != nil {
		a.emit("check", map[string]any{"error": err.Error()})
		return
	}
	a.mu.Lock()
	a.latest, a.asset = rel, asset
	a.mu.Unlock()
	installed, ver := installedVersion(a.modDir())
	update := !installed || ver == "unknown" || compareVersions(rel.Tag, ver) > 0
	a.emit("check", map[string]any{
		"version":         normVersion(rel.Tag),
		"title":           rel.Name,
		"notes":           rel.Body,
		"publishedAt":     rel.PublishedAt,
		"size":            asset.Size,
		"updateAvailable": update,
	})
}

// runUpdate downloads the latest release and installs it into mods\<ModFolder>.
func (a *App) runUpdate() map[string]any {
	fail := func(err error) map[string]any { return map[string]any{"ok": false, "error": err.Error()} }

	a.mu.Lock()
	rel, asset := a.latest, a.asset
	a.mu.Unlock()
	if rel == nil || asset == nil {
		return fail(errors.New("check for updates first"))
	}
	if !isGameDir(a.gameDir) {
		return fail(errors.New("the game folder isn't set"))
	}
	if p := runningProcess("D2R.exe", "D2RLoader.exe"); p != "" {
		return map[string]any{"ok": false, "gameRunning": true, "error": p + " is still running"}
	}

	// Can we write to the game folder? If not (Program Files), ask for elevation before downloading.
	if err := os.MkdirAll(a.workDir(), 0o755); err != nil {
		if isAccessDenied(err) {
			return map[string]any{"ok": false, "needsAdmin": true}
		}
		return fail(err)
	}
	probe := filepath.Join(a.workDir(), ".write-test")
	if err := os.WriteFile(probe, []byte("ok"), 0o644); err != nil {
		if isAccessDenied(err) {
			return map[string]any{"ok": false, "needsAdmin": true}
		}
		return fail(err)
	}
	os.Remove(probe)
	if err := os.MkdirAll(filepath.Join(a.gameDir, "mods"), 0o755); err != nil {
		return fail(err)
	}

	// 1. Download to %TEMP%.
	tmp := filepath.Join(os.TempDir(), a.cfg.ModFolder+"Launcher")
	os.MkdirAll(tmp, 0o755)
	zipPath := filepath.Join(tmp, unsafeChars.ReplaceAllString(asset.Name, "_"))
	var lastEmit time.Time
	err := downloadFile(context.Background(), asset.URL, zipPath, asset.Size, func(done, total int64) {
		if time.Since(lastEmit) > 120*time.Millisecond || done == total {
			lastEmit = time.Now()
			a.emit("progress", map[string]any{"phase": "download", "done": done, "total": total})
		}
	})
	if err != nil {
		return fail(err)
	}
	defer os.Remove(zipPath)

	// 2. Unpack into a staging folder next to mods\.
	staging := filepath.Join(a.workDir(), "staging")
	os.RemoveAll(staging)
	a.emit("progress", map[string]any{"phase": "install", "text": "Unpacking…", "pct": 0})
	err = extractZip(zipPath, staging, func(done, total int) {
		if time.Since(lastEmit) > 120*time.Millisecond || done == total {
			lastEmit = time.Now()
			a.emit("progress", map[string]any{"phase": "install", "text": "Unpacking…",
				"detail": fmt.Sprintf("%d of %d files", done, total), "pct": float64(done) / float64(total) * 100})
		}
	})
	if err != nil {
		os.RemoveAll(staging)
		return fail(err)
	}

	// 3. Keep the player's own settings, then swap folders (old one goes to backups).
	a.emit("progress", map[string]any{"phase": "install", "text": "Installing…"})
	_, oldVer := installedVersion(a.modDir())
	if err := preserveFiles(a.modDir(), staging, a.cfg.Preserve); err != nil {
		os.RemoveAll(staging)
		return fail(fmt.Errorf("couldn't keep your settings: %w", err))
	}
	if err := os.WriteFile(filepath.Join(staging, versionFile), []byte(normVersion(rel.Tag)+"\n"), 0o644); err != nil {
		os.RemoveAll(staging)
		return fail(err)
	}
	if err := swapIn(a.modDir(), staging, filepath.Join(a.workDir(), "backups"), oldVer, a.keepBackups()); err != nil {
		os.RemoveAll(staging)
		return fail(err)
	}
	res := map[string]any{"ok": true, "version": normVersion(rel.Tag)}
	if err := a.afterModSwap(); err != nil {
		res["warning"] = "Some of your plugins for this mod couldn't be put back: " + err.Error()
	}
	return res
}

func isAccessDenied(err error) bool {
	return errors.Is(err, windows.ERROR_ACCESS_DENIED) || errors.Is(err, os.ErrPermission)
}

// ---------- settings ----------

type settingsIn struct {
	CloseOnLaunch bool   `json:"closeOnLaunch"`
	AutoInstall   bool   `json:"autoInstall"`
	LaunchOptions string `json:"launchOptions"`
	Effects       bool   `json:"effects"`
	KeepBackups   int    `json:"keepBackups"`
}

func (a *App) closeOnLaunch() bool {
	if a.settings.CloseOnLaunch != nil {
		return *a.settings.CloseOnLaunch
	}
	return a.cfg.CloseOnLaunch
}

func (a *App) keepBackups() int {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.settings.KeepBackups != nil {
		return *a.settings.KeepBackups
	}
	return a.cfg.KeepBackups
}

func (a *App) settingsView() map[string]any {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.settingsViewLocked()
}

func (a *App) settingsViewLocked() map[string]any {
	keep := a.cfg.KeepBackups
	if a.settings.KeepBackups != nil {
		keep = *a.settings.KeepBackups
	}
	effects := a.settings.Effects == nil || *a.settings.Effects
	var backups []BackupInfo
	if isGameDir(a.gameDir) {
		backups = listBackups(filepath.Join(a.workDir(), "backups"), a.cfg.ModFolder)
	}
	if backups == nil {
		backups = []BackupInfo{}
	}
	return map[string]any{
		"closeOnLaunch": a.closeOnLaunch(),
		"autoInstall":   a.settings.AutoInstall,
		"launchOptions": a.settings.LaunchOptions,
		"effects":       effects,
		"keepBackups":   keep,
		"backups":       backups,
	}
}

func repoURL(repo string) string {
	if repo == "" {
		return ""
	}
	return "https://github.com/" + repo
}

// runRollback swaps a backup back into mods\<ModFolder>.
func (a *App) runRollback(name string) map[string]any {
	if p := runningProcess("D2R.exe", "D2RLoader.exe"); p != "" {
		return map[string]any{"ok": false, "gameRunning": true, "error": p + " is still running"}
	}
	probe := filepath.Join(a.workDir(), ".write-test")
	if err := os.WriteFile(probe, []byte("ok"), 0o644); err != nil {
		if isAccessDenied(err) {
			return map[string]any{"ok": false, "needsAdmin": true}
		}
		return map[string]any{"ok": false, "error": err.Error()}
	}
	os.Remove(probe)
	_, cur := installedVersion(a.modDir())
	if err := rollback(a.modDir(), filepath.Join(a.workDir(), "backups"), name, cur, a.cfg.Preserve, a.keepBackups()); err != nil {
		return map[string]any{"ok": false, "error": err.Error()}
	}
	_, now := installedVersion(a.modDir())
	res := map[string]any{"ok": true, "version": now}
	if err := a.afterModSwap(); err != nil {
		res["warning"] = "Some of your plugins for this mod couldn't be put back: " + err.Error()
	}
	return res
}
