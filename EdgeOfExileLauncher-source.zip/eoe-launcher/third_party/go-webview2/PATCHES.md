Local changes to jchv/go-webview2 (MIT) for the Edge of Exile launcher:

- webview.go NewWithOptions: disable zoom, status bar and browser accelerator keys (unless Debug); set the default background to #0b0706 so the window never flashes white.
