package main

import (
	"bytes"
	"debug/pe"
	"encoding/binary"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func relsOf(p *InstallPlan) string {
	var r []string
	for _, f := range p.Files {
		r = append(r, f.Rel)
	}
	return strings.Join(r, ",")
}

func TestPlanLayouts(t *testing.T) {
	dir := t.TempDir()
	cases := []struct {
		name, zipName string
		files         map[string]string
		want, scope   string
		skipped       int
	}{
		{"game layout", "Charm Inventory-1174-1-0-2-1760000000.zip",
			map[string]string{"d2rloader/plugins/d2rl-charm-inv.dll": "x", "d2rloader/plugins/d2rl-charm-inv.mpq": "x"},
			"plugins/d2rl-charm-inv.dll,plugins/d2rl-charm-inv.mpq", ScopeGlobal, 0},
		{"wrapped in a folder", "charm.zip",
			map[string]string{"Charm Inventory/d2rloader/plugins/a.dll": "x", "Charm Inventory/README.txt": "r"},
			"plugins/a.dll", ScopeGlobal, 1},
		{"loose files", "loose.zip",
			map[string]string{"cool.dll": "x", "cool.mpq": "x", "tweak.json": "{}", "cool.toml": "a=1", "readme.md": "r"},
			"config/cool.toml,patches/tweak.json,plugins/cool.dll,plugins/cool.mpq", ScopeGlobal, 1},
		{"mod scoped", "ms.zip",
			map[string]string{"mods/Whatever/d2rloader/plugins/m.dll": "x"},
			"plugins/m.dll", ScopeMod, 0},
		{"folder mpq", "fm.zip",
			map[string]string{"thing.dll": "x", "thing.mpq/data/global/ui/a.json": "{}"},
			"plugins/thing.dll,plugins/thing.mpq/data/global/ui/a.json", ScopeGlobal, 0},
		{"windows slashes", "ws.zip",
			map[string]string{`d2rloader\plugins\w.dll`: "x"},
			"plugins/w.dll", ScopeGlobal, 0},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			zp := filepath.Join(dir, c.name+".zip")
			writeZip(t, zp, c.files)
			p, err := planPluginZip(zp, c.zipName)
			if err != nil {
				t.Fatal(err)
			}
			if got := relsOf(p); got != c.want {
				t.Fatalf("files %s want %s", got, c.want)
			}
			if p.SuggestedScope != c.scope || len(p.Skipped) != c.skipped {
				t.Fatalf("scope %s skipped %v", p.SuggestedScope, p.Skipped)
			}
		})
	}
}

func TestPlanRejects(t *testing.T) {
	dir := t.TempDir()
	for name, files := range map[string]map[string]string{
		"loader":   {"D2RLoader.exe": "x", "d2rloader/plugins/a.dll": "x"},
		"mod":      {"MyMod/modinfo.json": "{}", "MyMod/MyMod.mpq/data/x.txt": "x"},
		"nothing":  {"readme.txt": "x", "pic.png": "x"},
		"unsafe":   {"../evil.dll": "x"},
		"dup":      {"a/x.dll": "1", "b/x.dll": "2"},
		"cfg only": {"x.toml": "a"},
	} {
		zp := filepath.Join(dir, strings.ReplaceAll(name, " ", "_")+".zip")
		writeZip(t, zp, files)
		if _, err := planPluginZip(zp, name+".zip"); err == nil {
			t.Errorf("%s: want an error", name)
		}
	}
}

func TestNameFromZip(t *testing.T) {
	for in, want := range map[string]string{
		"Charm Inventory-1174-1-0-2-1760000000.zip": "Charm Inventory|1.0.2",
		"loot-filter-v2.3.zip":                      "loot-filter|2.3",
		"stash.zip":                                 "stash|",
	} {
		n, v := nameFromZip(in)
		if n+"|"+v != want {
			t.Errorf("%s -> %s|%s", in, n, v)
		}
	}
	if prettyName("d2rl-charm-inv.dll") != "Charm Inv" {
		t.Error(prettyName("d2rl-charm-inv.dll"))
	}
}

func TestInstallToggleRemoveAndList(t *testing.T) {
	game := t.TempDir()
	global := filepath.Join(game, "d2rloader")
	modRoot := filepath.Join(game, "mods", "EdgeOfExile", "d2rloader")
	os.MkdirAll(filepath.Join(modRoot, "plugins"), 0o755)
	os.WriteFile(filepath.Join(modRoot, "plugins", "eoe-core.dll"), []byte("core"), 0o644)
	os.MkdirAll(filepath.Join(global, "plugins"), 0o755)
	os.WriteFile(filepath.Join(global, "plugins", "manual.dll"), []byte("m"), 0o644)
	os.MkdirAll(filepath.Join(global, "config"), 0o755)
	os.WriteFile(filepath.Join(global, "config", "charm.toml"), []byte("player-edit"), 0o644)

	zp := filepath.Join(game, "Charm Inventory-1174-1-0-0-1760000000.zip")
	writeZip(t, zp, map[string]string{
		"d2rloader/plugins/charm.dll": "v1", "d2rloader/plugins/charm-old.mpq": "old",
		"d2rloader/config/charm.toml": "default",
	})
	plan, err := planPluginZip(zp, filepath.Base(zp))
	if err != nil {
		t.Fatal(err)
	}
	markExisting(plan, global)
	if !plan.Files[0].Exists || plan.Files[0].Rel != "config/charm.toml" {
		t.Fatalf("config should be marked existing: %+v", plan.Files)
	}
	inst, err := installPlugin(zp, plan, global, "", nil)
	if err != nil {
		t.Fatal(err)
	}
	inst.Scope = ScopeGlobal
	if read(t, filepath.Join(global, "config", "charm.toml")) != "player-edit" {
		t.Fatal("existing plugin settings were overwritten")
	}
	reg := &PluginRegistry{Plugins: []InstalledPlugin{*inst}}

	views := listPlugins(reg, global, modRoot)
	byOrigin := map[string][]string{}
	for _, v := range views {
		byOrigin[v.Origin] = append(byOrigin[v.Origin], v.Name)
	}
	if strings.Join(byOrigin["launcher"], ",") != "Charm Inventory" || strings.Join(byOrigin["found"], ",") != "Manual" ||
		strings.Join(byOrigin["mod"], ",") != "Eoe Core" {
		t.Fatalf("views by origin: %v", byOrigin)
	}

	// Turn it off and on.
	if err := setItemsEnabled(global, inst.Files, false); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(global, "plugins", "charm.dll.disabled")); err != nil {
		t.Fatal("dll not disabled")
	}
	if _, err := os.Stat(filepath.Join(global, "config", "charm.toml")); err != nil {
		t.Fatal("config should never be renamed")
	}
	inst.Enabled = false

	// Reinstall a new version while disabled: it comes back on and the dropped .mpq goes away.
	zp2 := filepath.Join(game, "Charm Inventory-1174-1-1-0-1760000001.zip")
	writeZip(t, zp2, map[string]string{"d2rloader/plugins/charm.dll": "v2"})
	plan2, _ := planPluginZip(zp2, filepath.Base(zp2))
	inst2, err := installPlugin(zp2, plan2, global, "", inst)
	if err != nil {
		t.Fatal(err)
	}
	if read(t, filepath.Join(global, "plugins", "charm.dll")) != "v2" || inst2.Version != "1.1.0" {
		t.Fatal("upgrade didn't land")
	}
	for _, gone := range []string{"charm-old.mpq", "charm-old.mpq.disabled", "charm.dll.disabled"} {
		if _, err := os.Stat(filepath.Join(global, "plugins", gone)); err == nil {
			t.Fatalf("%s should be gone", gone)
		}
	}

	// Remove moves files to trash and keeps settings.
	trash := filepath.Join(game, "trash")
	if err := removeItems(global, inst2.Files, trash); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(global, "plugins", "charm.dll")); err == nil {
		t.Fatal("dll still installed")
	}
	if read(t, filepath.Join(trash, "plugins", "charm.dll")) != "v2" {
		t.Fatal("dll not in trash")
	}
	if read(t, filepath.Join(global, "config", "charm.toml")) != "player-edit" {
		t.Fatal("settings removed")
	}
}

func TestModScopedPluginsSurviveModUpdate(t *testing.T) {
	game := t.TempDir()
	modD2RL := filepath.Join(game, "mods", "EdgeOfExile", "d2rloader")
	store := filepath.Join(game, "store")
	zp := filepath.Join(game, "extra.zip")
	writeZip(t, zp, map[string]string{"extra.dll": "x", "extra.mpq/data/a.txt": "a"})
	plan, _ := planPluginZip(zp, "extra.zip")
	inst, err := installPlugin(zp, plan, modD2RL, filepath.Join(store, plan.ID), nil)
	if err != nil {
		t.Fatal(err)
	}
	inst.Scope, inst.Enabled = ScopeMod, false
	reg := &PluginRegistry{Plugins: []InstalledPlugin{*inst}}

	os.RemoveAll(filepath.Join(game, "mods")) // a mod update replaces the whole folder
	if err := restoreModPlugins(reg, store, modD2RL); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(modD2RL, "plugins", "extra.dll.disabled")); err != nil {
		t.Fatal("disabled plugin not restored as disabled")
	}
	if read(t, filepath.Join(modD2RL, "plugins", "extra.mpq.disabled", "data", "a.txt")) != "a" {
		t.Fatal("folder mpq not restored")
	}
}

// buildPluginDLL writes a minimal PE32+ image whose D2RLoaderGetPluginInfo is `lea rax,[rip+x]; ret`.
func buildPluginDLL(t *testing.T, file string, thunk bool) {
	t.Helper()
	const base, secRVA, secOff = 0x180000000, 0x1000, 0x400
	sec := make([]byte, 0x400)
	put32 := func(off int, v uint32) { binary.LittleEndian.PutUint32(sec[off:], v) }
	put64 := func(off int, v uint64) { binary.LittleEndian.PutUint64(sec[off:], v) }
	put32(20, 1)
	put32(24, 1)
	put32(28, secRVA+0x40)
	put32(32, secRVA+0x44)
	put32(36, secRVA+0x48)
	fn := uint32(secRVA + 0x100)
	put32(0x44, secRVA+0x50)
	copy(sec[0x50:], "D2RLoaderGetPluginInfo\x00")
	code := 0x100
	if thunk {
		put32(0x40, secRVA+0xF0)
		sec[0xF0] = 0xE9
		put32(0xF1, uint32(int32(fn)-int32(secRVA+0xF0+5)))
	} else {
		put32(0x40, fn)
	}
	sec[code], sec[code+1], sec[code+2] = 0x48, 0x8D, 0x05
	put32(code+3, uint32(secRVA+0x200-(int(fn)+7)))
	sec[code+7] = 0xC3
	put32(0x200, 56)
	put32(0x204, 1)
	put64(0x208, base+secRVA+0x300)
	put64(0x210, base+secRVA+0x310)
	put64(0x218, base+secRVA+0x330)
	put64(0x220, 0)
	put64(0x228, base+secRVA+0x340)
	put64(0x230, 7)
	copy(sec[0x300:], "charm-inv\x00")
	copy(sec[0x310:], "Charm Inventory\x00")
	copy(sec[0x330:], "1.2.0\x00")
	copy(sec[0x340:], "A separate charm inventory\x00")

	var b bytes.Buffer
	dos := make([]byte, 0x80)
	dos[0], dos[1] = 'M', 'Z'
	binary.LittleEndian.PutUint32(dos[0x3c:], 0x80)
	b.Write(dos)
	b.WriteString("PE\x00\x00")
	binary.Write(&b, binary.LittleEndian, pe.FileHeader{Machine: 0x8664, NumberOfSections: 1, SizeOfOptionalHeader: 240, Characteristics: 0x2022})
	oh := pe.OptionalHeader64{Magic: 0x20b, ImageBase: base, SectionAlignment: 0x1000, FileAlignment: 0x200,
		SizeOfImage: 0x2000, SizeOfHeaders: 0x400, NumberOfRvaAndSizes: 16}
	oh.DataDirectory[0] = pe.DataDirectory{VirtualAddress: secRVA, Size: 40}
	binary.Write(&b, binary.LittleEndian, oh)
	sh := pe.SectionHeader32{VirtualSize: 0x400, VirtualAddress: secRVA, SizeOfRawData: 0x400, PointerToRawData: secOff, Characteristics: 0x60000020}
	copy(sh.Name[:], ".text")
	binary.Write(&b, binary.LittleEndian, sh)
	b.Write(make([]byte, secOff-b.Len()))
	b.Write(sec)
	if err := os.WriteFile(file, b.Bytes(), 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestReadPluginInfo(t *testing.T) {
	for _, thunk := range []bool{false, true} {
		f := filepath.Join(t.TempDir(), "charm.dll")
		buildPluginDLL(t, f, thunk)
		info, ok := readPluginInfo(f)
		if !ok || info.ID != "charm-inv" || info.Name != "Charm Inventory" || info.Version != "1.2.0" ||
			info.Author != "" || info.Description != "A separate charm inventory" {
			t.Fatalf("thunk=%v: %+v ok=%v", thunk, info, ok)
		}
	}
	junk := filepath.Join(t.TempDir(), "junk.dll")
	os.WriteFile(junk, []byte("not a pe"), 0o644)
	if _, ok := readPluginInfo(junk); ok {
		t.Fatal("junk parsed")
	}
}
