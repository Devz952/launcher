//go:build windows

package main

// Small Win32 helpers: DPI, window placement, dark title bar, folder picker, process checks.

import (
	"errors"
	"strings"
	"syscall"
	"unsafe"

	"golang.org/x/sys/windows"
)

var (
	user32   = windows.NewLazySystemDLL("user32.dll")
	shell32  = windows.NewLazySystemDLL("shell32.dll")
	dwmapi   = windows.NewLazySystemDLL("dwmapi.dll")
	ole32    = windows.NewLazySystemDLL("ole32.dll")
	kernel32 = windows.NewLazySystemDLL("kernel32.dll")

	procSetProcessDpiAwarenessContext = user32.NewProc("SetProcessDpiAwarenessContext")
	procGetDpiForWindow               = user32.NewProc("GetDpiForWindow")
	procGetWindowRect                 = user32.NewProc("GetWindowRect")
	procSetWindowPos                  = user32.NewProc("SetWindowPos")
	procSystemParametersInfoW         = user32.NewProc("SystemParametersInfoW")
	procFindWindowW                   = user32.NewProc("FindWindowW")
	procSetForegroundWindow           = user32.NewProc("SetForegroundWindow")
	procShowWindow                    = user32.NewProc("ShowWindow")
	procIsIconic                      = user32.NewProc("IsIconic")
	procDwmSetWindowAttribute         = dwmapi.NewProc("DwmSetWindowAttribute")
	procCoCreateInstance              = ole32.NewProc("CoCreateInstance")
	procSHCreateItemFromParsingName   = shell32.NewProc("SHCreateItemFromParsingName")
	procCreateMutexW                  = kernel32.NewProc("CreateMutexW")
)

type rect struct{ Left, Top, Right, Bottom int32 }

func enableDPIAwareness() {
	if procSetProcessDpiAwarenessContext.Find() == nil {
		// DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4
		procSetProcessDpiAwarenessContext.Call(uintptr(^uintptr(3)))
	}
}

func windowDPI(hwnd uintptr) int {
	if procGetDpiForWindow.Find() == nil {
		if d, _, _ := procGetDpiForWindow.Call(hwnd); d > 0 {
			return int(d)
		}
	}
	return 96
}

// centerWindow puts the window in the middle of the primary monitor's work area.
func centerWindow(hwnd uintptr) {
	var wr, work rect
	procGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&wr)))
	procSystemParametersInfoW.Call(0x0030 /*SPI_GETWORKAREA*/, 0, uintptr(unsafe.Pointer(&work)), 0)
	w, h := wr.Right-wr.Left, wr.Bottom-wr.Top
	x := work.Left + (work.Right-work.Left-w)/2
	y := work.Top + (work.Bottom-work.Top-h)/2
	if y < work.Top {
		y = work.Top
	}
	procSetWindowPos.Call(hwnd, 0, uintptr(x), uintptr(y), 0, 0, 0x0001|0x0004|0x0010) // NOSIZE|NOZORDER|NOACTIVATE
}

// darkTitleBar gives the window a dark caption (Windows 10 20H1+) tinted to match the art (Windows 11).
func darkTitleBar(hwnd uintptr) {
	if procDwmSetWindowAttribute.Find() != nil {
		return
	}
	on := int32(1)
	procDwmSetWindowAttribute.Call(hwnd, 20 /*DWMWA_USE_IMMERSIVE_DARK_MODE*/, uintptr(unsafe.Pointer(&on)), 4)
	caption := uint32(0x0006070b) // COLORREF 0x00BBGGRR for #0b0706
	procDwmSetWindowAttribute.Call(hwnd, 35 /*DWMWA_CAPTION_COLOR*/, uintptr(unsafe.Pointer(&caption)), 4)
	text := uint32(0x00c7e2f3)
	procDwmSetWindowAttribute.Call(hwnd, 36 /*DWMWA_TEXT_COLOR*/, uintptr(unsafe.Pointer(&text)), 4)
}

func focusExistingWindow(title string) {
	cls, _ := windows.UTF16PtrFromString("webview")
	t, _ := windows.UTF16PtrFromString(title)
	if h, _, _ := procFindWindowW.Call(uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(t))); h != 0 {
		if ic, _, _ := procIsIconic.Call(h); ic != 0 {
			procShowWindow.Call(h, 9 /*SW_RESTORE*/)
		}
		procSetForegroundWindow.Call(h)
	}
}

// singleInstance takes a named mutex. When wait is true (a restart after elevation) it waits for the
// previous instance to exit instead of giving up.
func singleInstance(name string, wait bool) bool {
	n, _ := windows.UTF16PtrFromString(name)
	h, _, err := procCreateMutexW.Call(0, 1, uintptr(unsafe.Pointer(n)))
	if h == 0 {
		return true // can't tell; don't block the player
	}
	if err != windows.ERROR_ALREADY_EXISTS {
		return true
	}
	if !wait {
		return false
	}
	ev, _ := windows.WaitForSingleObject(windows.Handle(h), 10000)
	return ev == windows.WAIT_OBJECT_0 || ev == windows.WAIT_ABANDONED
}

func messageBox(hwnd uintptr, title, text string, flags uint32) int32 {
	t, _ := windows.UTF16PtrFromString(title)
	m, _ := windows.UTF16PtrFromString(text)
	r, _ := windows.MessageBox(windows.HWND(hwnd), m, t, flags)
	return r
}

func shellOpen(hwnd uintptr, verb, file, args, dir string) error {
	v, _ := windows.UTF16PtrFromString(verb)
	f, _ := windows.UTF16PtrFromString(file)
	var a, d *uint16
	if args != "" {
		a, _ = windows.UTF16PtrFromString(args)
	}
	if dir != "" {
		d, _ = windows.UTF16PtrFromString(dir)
	}
	return windows.ShellExecute(windows.Handle(hwnd), v, f, a, d, windows.SW_SHOWNORMAL)
}

func isCancelled(err error) bool { return errors.Is(err, windows.ERROR_CANCELLED) }

// runningProcess returns the first of names (e.g. "D2R.exe") that is currently running.
func runningProcess(names ...string) string {
	snap, err := windows.CreateToolhelp32Snapshot(windows.TH32CS_SNAPPROCESS, 0)
	if err != nil {
		return ""
	}
	defer windows.CloseHandle(snap)
	var pe windows.ProcessEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	for err = windows.Process32First(snap, &pe); err == nil; err = windows.Process32Next(snap, &pe) {
		exe := windows.UTF16ToString(pe.ExeFile[:])
		for _, n := range names {
			if strings.EqualFold(exe, n) {
				return n
			}
		}
	}
	return ""
}

// ---------- modern folder picker (IFileOpenDialog with FOS_PICKFOLDERS) ----------

var (
	clsidFileOpenDialog = windows.GUID{Data1: 0xDC1C5A9C, Data2: 0xE88A, Data3: 0x4DDE, Data4: [8]byte{0xA5, 0xA1, 0x60, 0xF8, 0x2A, 0x20, 0xAE, 0xF7}}
	iidIFileOpenDialog  = windows.GUID{Data1: 0xd57c7288, Data2: 0xd4ad, Data3: 0x4768, Data4: [8]byte{0xbe, 0x02, 0x9d, 0x96, 0x95, 0x32, 0xd9, 0x60}}
	iidIShellItem       = windows.GUID{Data1: 0x43826d1e, Data2: 0xe718, Data3: 0x42ee, Data4: [8]byte{0xbc, 0x55, 0xa1, 0xe2, 0x61, 0xc3, 0x7b, 0xfe}}
)

type comObj struct{ vtbl *[32]uintptr }

func (o *comObj) call(index int, args ...uintptr) uintptr {
	all := append([]uintptr{uintptr(unsafe.Pointer(o))}, args...)
	r, _, _ := syscall.SyscallN(o.vtbl[index], all...)
	return r
}
func (o *comObj) release() { o.call(2) }

// pickFolder shows the Windows folder picker. It returns "" if the player cancels.
func pickFolder(owner uintptr, title, start string) (string, error) {
	return pickPath(owner, title, start, true, "", "")
}

// pickFile shows the Windows file picker filtered to one file type, e.g. ("Zip files", "*.zip").
func pickFile(owner uintptr, title, start, filterName, filterSpec string) (string, error) {
	return pickPath(owner, title, start, false, filterName, filterSpec)
}

type filterSpec struct{ name, spec *uint16 }

func pickPath(owner uintptr, title, start string, folders bool, filterName, filter string) (string, error) {
	var dlg *comObj
	hr, _, _ := procCoCreateInstance.Call(uintptr(unsafe.Pointer(&clsidFileOpenDialog)), 0, 1 /*CLSCTX_INPROC_SERVER*/,
		uintptr(unsafe.Pointer(&iidIFileOpenDialog)), uintptr(unsafe.Pointer(&dlg)))
	if hr != 0 || dlg == nil {
		return "", errors.New("couldn't open the file picker")
	}
	defer dlg.release()

	var opts uint32
	dlg.call(10, uintptr(unsafe.Pointer(&opts))) // GetOptions
	opts |= 0x40 | 0x800                         // FORCEFILESYSTEM | PATHMUSTEXIST
	if folders {
		opts |= 0x20 // PICKFOLDERS
	} else {
		opts |= 0x1000 // FILEMUSTEXIST
	}
	dlg.call(9, uintptr(opts)) // SetOptions
	if !folders && filter != "" {
		n, _ := windows.UTF16PtrFromString(filterName)
		f, _ := windows.UTF16PtrFromString(filter)
		specs := []filterSpec{{n, f}}
		dlg.call(4, 1, uintptr(unsafe.Pointer(&specs[0]))) // SetFileTypes
	}
	if t, err := windows.UTF16PtrFromString(title); err == nil {
		dlg.call(17, uintptr(unsafe.Pointer(t))) // SetTitle
	}
	if start != "" {
		if p, err := windows.UTF16PtrFromString(start); err == nil {
			var item *comObj
			if r, _, _ := procSHCreateItemFromParsingName.Call(uintptr(unsafe.Pointer(p)), 0,
				uintptr(unsafe.Pointer(&iidIShellItem)), uintptr(unsafe.Pointer(&item))); r == 0 && item != nil {
				if folders {
					dlg.call(12, uintptr(unsafe.Pointer(item))) // SetFolder: open right at the current game folder
				} else {
					dlg.call(11, uintptr(unsafe.Pointer(item))) // SetDefaultFolder: a folder Windows remembers wins
				}
				item.release()
			}
		}
	}
	if hr := dlg.call(3, owner); hr != 0 { // Show; HRESULT_FROM_WIN32(ERROR_CANCELLED) when closed
		return "", nil
	}
	var item *comObj
	if hr := dlg.call(20, uintptr(unsafe.Pointer(&item))); hr != 0 || item == nil { // GetResult
		return "", errors.New("couldn't read your choice")
	}
	defer item.release()
	var name *uint16
	if hr := item.call(5, 0x80058000 /*SIGDN_FILESYSPATH*/, uintptr(unsafe.Pointer(&name))); hr != 0 || name == nil {
		return "", errors.New("that location isn't a normal file or folder")
	}
	defer windows.CoTaskMemFree(unsafe.Pointer(name))
	return windows.UTF16PtrToString(name), nil
}
