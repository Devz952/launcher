"use strict";
// UI for the Edge of Exile launcher. The Go side exposes these functions on window
// (each returns a Promise): getState, checkForUpdates, startUpdate, play, chooseGameDir, saveSettings,
// rollback, openUrl, openModFolder, openBackupsFolder, restartAsAdmin. Long work reports back
// through window.__emit(event, data).

const $ = (id) => document.getElementById(id);
const api = window.__mockApi || window;
const DISCORD_URL = "https://discord.gg/6WcHuRrJH3";

const ui = {
  dot: $("dot"), headline: $("headline"), detail: $("detail"),
  progress: $("progress"), bar: $("bar"),
  play: $("play"), playLabel: $("playLabel"),
  notesBtn: $("notesBtn"),
  notes: $("notes"), notesTitle: $("notesTitle"), notesBody: $("notesBody"),
  modal: $("modal"), modalTitle: $("modalTitle"), modalText: $("modalText"), modalActions: $("modalActions"),
};

let state = null;      // from getState()
let release = null;    // latest release info from checkForUpdates
let action = null;     // what the big button does right now
let busy = false;

// ---------- rendering helpers ----------
function setStatus(kind, headline, detail) {
  ui.dot.className = "dot " + (kind || "");
  ui.headline.textContent = headline;
  ui.detail.innerHTML = "&nbsp;";
  if (detail) ui.detail.textContent = detail;
}
function setButton(label, act, enabled = true) {
  ui.playLabel.textContent = label;
  ui.play.classList.toggle("long", label.length > 7);
  action = act;
  ui.play.disabled = !enabled;
  ui.play.classList.toggle("glow", enabled && (act === "play" || act === "update" || act === "install"));
}
function setProgress(pct) {
  if (pct === null) { ui.progress.hidden = true; return; }
  ui.progress.hidden = false;
  if (pct === "indeterminate") { ui.progress.classList.add("indeterminate"); ui.bar.style.width = ""; return; }
  ui.progress.classList.remove("indeterminate");
  ui.bar.style.width = Math.max(0, Math.min(100, pct)).toFixed(1) + "%";
}
function fmtSize(bytes) {
  if (!bytes) return "";
  const mb = bytes / (1024 * 1024);
  return mb >= 100 ? Math.round(mb) + " MB" : mb >= 1 ? mb.toFixed(1) + " MB" : Math.max(1, Math.round(bytes / 1024)) + " KB";
}
function v(s) { return s ? (/^\d/.test(s) ? "v" + s : s) : "?"; }

function modal(title, text, buttons, opts = {}) {
  ui.modalTitle.textContent = title;
  ui.modalText.textContent = text;
  ui.modalText.hidden = !text;
  const box = ui.modal.querySelector(".modal");
  box.classList.toggle("wide", !!opts.wide);
  box.querySelectorAll(".modal-extra").forEach((n) => n.remove());
  if (opts.node) { opts.node.classList.add("modal-extra"); ui.modalActions.before(opts.node); }
  ui.modalActions.innerHTML = "";
  for (const b of buttons) {
    const el = document.createElement("button");
    el.type = "button";
    el.className = "btn" + (b.primary ? " primary" : "");
    el.textContent = b.label;
    el.onclick = () => { closeModal(); b.run && b.run(); };
    ui.modalActions.appendChild(el);
  }
  ui.modal.hidden = false;
  const first = ui.modalActions.querySelector(".primary") || ui.modalActions.firstChild;
  first && first.focus();
}
function closeModal() { ui.modal.hidden = true; }

// Tiny, safe markdown subset for GitHub release notes: headings, bullets, paragraphs, `code`, **bold**.
function renderNotes(md) {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const inline = (s) => esc(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  const out = [];
  let list = false;
  for (const raw of (md || "").replace(/\r/g, "").split("\n")) {
    const line = raw.trimEnd();
    const h = line.match(/^#{1,6}\s+(.*)/);
    const li = line.match(/^\s*[-*+]\s+(.*)/);
    if (!li && list) { out.push("</ul>"); list = false; }
    if (h) out.push("<h3>" + inline(h[1]) + "</h3>");
    else if (li) { if (!list) { out.push("<ul>"); list = true; } out.push("<li>" + inline(li[1]) + "</li>"); }
    else if (line.trim()) out.push("<p>" + inline(line) + "</p>");
  }
  if (list) out.push("</ul>");
  return out.join("") || '<p class="muted">No notes were published with this release.</p>';
}

function showNotes() {
  if (!release) return;
  ui.notesTitle.textContent = "Patch notes — " + v(release.version);
  ui.notesBody.innerHTML = renderNotes(release.notes);
  if (release.publishedAt) {
    const d = new Date(release.publishedAt);
    if (!isNaN(d)) ui.notesBody.insertAdjacentHTML("afterbegin",
      '<p class="muted">Released ' + d.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }) + "</p>");
  }
  ui.notes.hidden = false;
}

// ---------- state machine ----------
async function refresh(check = true) {
  closeModal();
  state = await api.getState();
  $("launcherVersion").textContent = "Launcher " + v(state.launcherVersion);
  ui.notesBtn.disabled = true;
  renderSettings();
  setProgress(null);

  if (!state.gameDirOk) {
    setStatus("error", "Diablo II: Resurrected not found", "Point the launcher at the folder that contains D2R.exe.");
    setButton("Locate game", "locate");
    modal("Where is Diablo II: Resurrected?",
      "The launcher couldn't find your game automatically. Choose the folder that contains D2R.exe — usually C:\\Program Files (x86)\\Diablo II Resurrected.",
      [{ label: "Choose folder", primary: true, run: chooseFolder }]);
    return;
  }
  if (!state.loaderFound) {
    setStatus("error", "D2RLoader is not installed", "D2RLoader.exe must sit in your game folder next to D2R.exe.");
    setButton("Get D2RLoader", "getloader");
    return;
  }
  if (state.repoConfigured && check) {
    setStatus("busy", "Checking for updates…", state.modInstalled ? "Installed " + v(state.installedVersion) : "");
    setButton("Checking", null, false);
    setProgress("indeterminate");
    api.checkForUpdates();
    return;
  }
  showIdle();
}

function showIdle() {
  setProgress(null);
  if (state.modInstalled) {
    const tail = state.repoConfigured ? "" : " · automatic updates not set up";
    setStatus("ready", "Ready to play", state.modName + " " + v(state.installedVersion) + tail);
    setButton("Play", "play");
  } else {
    setStatus("error", state.modName + " isn't installed", state.repoConfigured
      ? "Couldn't reach the update server."
      : "No update source is set up for this launcher yet.");
    setButton(state.repoConfigured ? "Retry" : "Play", state.repoConfigured ? "retry" : null, state.repoConfigured);
  }
}

function onCheck(res) {
  setProgress(null);
  if (res.error) {
    release = null;
    if (state.modInstalled) {
      setStatus("ready", "Ready to play", "Couldn't check for updates: " + res.error);
      setButton("Play", "play");
    } else {
      setStatus("error", "Couldn't download " + state.modName, res.error);
      setButton("Retry", "retry");
    }
    return;
  }
  release = res;
  ui.notesBtn.disabled = false;
  const size = fmtSize(res.size);
  if (!state.modInstalled) {
    setStatus("update", state.modName + " isn't installed yet", "Latest " + v(res.version) + (size ? " · " + size + " download" : ""));
    setButton("Install", "install");
  } else if (res.updateAvailable) {
    setStatus("update", "Update available: " + v(res.version), "You have " + v(state.installedVersion) + (size ? " · " + size + " download" : ""));
    setButton("Update", "update");
  } else {
    setStatus("ready", "Ready to play", state.modName + " " + v(state.installedVersion) + " · up to date");
    setButton("Play", "play");
  }
  const wantsAuto = state.autoUpdate || (state.settings.autoInstall && res.updateAvailable && state.modInstalled);
  if (wantsAuto && (action === "update" || action === "install")) { state.autoUpdate = false; startUpdate(); }
  renderSettings();
}

function onProgress(p) {
  if (p.phase === "download") {
    setStatus("busy", "Downloading " + v(release && release.version) + "…",
      p.total ? fmtSize(p.done) + " of " + fmtSize(p.total) : fmtSize(p.done));
    setProgress(p.total ? (p.done / p.total) * 100 : "indeterminate");
  } else {
    setStatus("busy", p.text || "Installing…", p.detail || "");
    setProgress(typeof p.pct === "number" ? p.pct : "indeterminate");
  }
}

async function onUpdateDone(res) {
  busy = false;
  renderSettings();
  if (res.ok) {
    await refresh(false);
    setStatus("ready", "Ready to play", state.modName + " " + v(state.installedVersion) + " installed");
    ui.notesBtn.disabled = !release;
    if (res.warning) modal("Update installed", res.warning, [{ label: "OK", primary: true }]);
    return;
  }
  setProgress(null);
  if (res.needsAdmin) {
    setStatus("error", "Windows needs your permission", "Your game folder is protected.");
    setButton("Update", "update");
    modal("Administrator permission needed",
      "Your game is installed in a protected folder, so Windows has to approve changes to it. The launcher will restart and ask once.",
      [{ label: "Cancel" }, { label: "Restart as administrator", primary: true, run: () => api.restartAsAdmin(true) }]);
    return;
  }
  setStatus("error", "Update failed", res.error || "Unknown error");
  setButton(state.modInstalled ? "Play" : "Retry", state.modInstalled ? "play" : "retry");
  if (res.gameRunning) {
    modal("Close the game first", "Diablo II: Resurrected is still running. Close it, then try the update again.",
      [{ label: "OK", primary: true }]);
  }
}

async function startUpdate() {
  if (busy) return;
  busy = true;
  ui.notes.hidden = true;
  showView("play");
  setButton("Updating", null, false);
  setStatus("busy", "Preparing update…", "");
  setProgress("indeterminate");
  renderSettings();
  api.startUpdate();
}

let folderWaiter = null;
async function chooseFolder() {
  if (folderWaiter) return;
  const res = await new Promise((resolve) => { folderWaiter = resolve; api.chooseGameDir(); });
  folderWaiter = null;
  if (res && res.error) {
    modal("That isn't a D2R folder", res.error, [{ label: "Try again", primary: true, run: chooseFolder }, { label: "Cancel" }]);
    return;
  }
  if (res && res.changed) { release = null; refresh(); }
}

ui.play.addEventListener("click", async () => {
  switch (action) {
    case "play": {
      setButton("Launching", null, false);
      setStatus("busy", "Summoning D2RLoader…", "");
      const r = await api.play();
      if (!r.ok) {
        setStatus("error", "Couldn't start D2RLoader", r.error || "");
        setButton("Play", "play");
      } else if (!r.closing) {
        setTimeout(() => { setStatus("ready", "Game launched", "Good hunting, exile."); setButton("Play", "play"); }, 1200);
      }
      break;
    }
    case "update": case "install": startUpdate(); break;
    case "retry": refresh(); break;
    case "locate": chooseFolder(); break;
    case "getloader": api.openUrl("https://d2rloader.net/download.html"); break;
  }
});
ui.notesBtn.addEventListener("click", () => (ui.notes.hidden ? showNotes() : (ui.notes.hidden = true)));
$("notesClose").addEventListener("click", () => (ui.notes.hidden = true));
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!ui.modal.hidden) { if (ui.modalActions.children.length > 1) closeModal(); return; }
  if (!ui.notes.hidden) { ui.notes.hidden = true; return; }
  if (view !== "play") showView("play");
});
document.addEventListener("contextmenu", (e) => e.preventDefault());

// ---------- settings tab ----------
const S = {
  panel: $("settings"), tabPlay: $("tabPlay"), tabSettings: $("tabSettings"),
  folder: $("setFolder"), folderBtn: $("setFolderBtn"),
  loader: $("setLoader"), loaderBtn: $("setLoaderBtn"),
  close: $("setClose"), args: $("setArgs"), auto: $("setAuto"), keep: $("setKeep"),
  reinstall: $("setReinstall"), repairHint: $("setRepairHint"),
  rollback: $("setRollback"), rollbackHint: $("setRollbackHint"),
  effects: $("setEffects"), saved: $("savedNote"),
  aboutMod: $("aboutMod"), aboutLauncher: $("aboutLauncher"),
  aboutModFolder: $("aboutModFolder"), aboutBackups: $("aboutBackups"),
  aboutRepo: $("aboutRepo"), aboutRepoSep: $("aboutRepoSep"),
};
let view = "play";

function showView(name) {
  view = name;
  const tabs = { play: S.tabPlay, plugins: $("tabPlugins"), settings: S.tabSettings };
  for (const [k, el] of Object.entries(tabs)) {
    el.classList.toggle("active", k === name);
    el.setAttribute("aria-selected", String(k === name));
  }
  S.panel.hidden = name !== "settings";
  $("plugins").hidden = name !== "plugins";
  document.body.classList.toggle("view-settings", name === "settings");
  document.body.classList.toggle("view-plugins", name === "plugins");
  if (name !== "play") ui.notes.hidden = true;
  if (name === "settings") renderSettings();
  if (name === "plugins") loadPlugins();
}

function fmtDate(iso) {
  const d = new Date(iso);
  return isNaN(d) ? "" : d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function renderSettings() {
  if (!state) return;
  const st = state.settings || {};
  S.folder.textContent = state.gameDir || "Not set";
  S.folder.title = state.gameDir || "";
  S.folderBtn.disabled = busy;

  S.loader.className = "hint " + (state.loaderFound ? "ok" : "bad");
  S.loader.textContent = !state.gameDirOk ? "Set your game folder first"
    : state.loaderFound ? "Found in your game folder" : "Not found in your game folder";
  S.loaderBtn.hidden = !state.gameDirOk || state.loaderFound;

  if (document.activeElement !== S.args) S.args.value = st.launchOptions || "";
  S.close.checked = !!st.closeOnLaunch;
  S.auto.checked = !!st.autoInstall;
  S.auto.disabled = !state.repoConfigured;
  S.keep.value = String(st.keepBackups ?? 2);
  S.effects.checked = st.effects !== false;

  const canReinstall = state.repoConfigured && !!release && !busy;
  S.reinstall.disabled = !canReinstall;
  S.reinstall.textContent = state.modInstalled ? "Reinstall" : "Install";
  S.repairHint.textContent = !state.repoConfigured ? "Automatic updates aren't set up for this launcher."
    : !release ? "Needs a connection to GitHub; check for updates first."
    : "Download " + v(release.version) + " again and replace damaged files. Your settings are kept.";

  const backups = st.backups || [];
  const latest = backups[0];
  S.rollback.disabled = !latest || busy || !state.gameDirOk;
  S.rollbackHint.textContent = latest
    ? "Go back to " + v(latest.version) + " (saved " + fmtDate(latest.when) + ")."
    : "No previous versions saved yet.";

  S.aboutMod.textContent = state.modName + " " + (state.modInstalled ? v(state.installedVersion) : "— not installed");
  S.aboutLauncher.textContent = v(state.launcherVersion);
  S.aboutModFolder.disabled = !state.modInstalled;
  S.aboutBackups.disabled = backups.length === 0;
  S.aboutRepo.hidden = S.aboutRepoSep.hidden = !state.repoUrl;

  document.body.classList.toggle("no-effects", st.effects === false);
  embers.set(st.effects !== false);
}

let savedTimer = 0;
async function persist() {
  const next = await api.saveSettings({
    closeOnLaunch: S.close.checked,
    autoInstall: S.auto.checked,
    launchOptions: S.args.value,
    effects: S.effects.checked,
    keepBackups: parseInt(S.keep.value, 10) || 0,
  });
  if (next) { state.settings = next; renderSettings(); }
  S.saved.textContent = "Saved";
  S.saved.classList.add("show");
  clearTimeout(savedTimer);
  savedTimer = setTimeout(() => S.saved.classList.remove("show"), 1400);
}

let argsTimer = 0;
for (const el of [S.close, S.auto, S.keep, S.effects]) el.addEventListener("change", persist);
S.args.addEventListener("input", () => { clearTimeout(argsTimer); argsTimer = setTimeout(persist, 600); });
S.args.addEventListener("keydown", (e) => { if (e.key === "Enter") { clearTimeout(argsTimer); persist(); S.args.blur(); } });

S.tabPlay.addEventListener("click", () => showView("play"));
S.tabSettings.addEventListener("click", () => showView("settings"));
$("settingsLink").addEventListener("click", () => showView("settings"));
S.folderBtn.addEventListener("click", () => { if (!busy) chooseFolder(); });
S.loaderBtn.addEventListener("click", () => api.openUrl("https://d2rloader.net/download.html"));
S.aboutModFolder.addEventListener("click", () => api.openModFolder());
S.aboutBackups.addEventListener("click", () => api.openBackupsFolder());
S.aboutRepo.addEventListener("click", () => state.repoUrl && api.openUrl(state.repoUrl));
$("aboutDiscord").addEventListener("click", () => api.openUrl(DISCORD_URL));
$("discordBtn").addEventListener("click", () => api.openUrl(DISCORD_URL));
$("tabPlugins").addEventListener("click", () => showView("plugins"));

S.reinstall.addEventListener("click", () => {
  if (!release || busy) return;
  modal(state.modInstalled ? "Reinstall " + state.modName + "?" : "Install " + state.modName + "?",
    "The launcher will download " + v(release.version) + " again" +
    (state.modInstalled ? " and replace the installed files. Your D2RLoader settings and characters are kept." : "."),
    [{ label: "Cancel" }, { label: state.modInstalled ? "Reinstall" : "Install", primary: true, run: startUpdate }]);
});

S.rollback.addEventListener("click", () => {
  const latest = ((state.settings || {}).backups || [])[0];
  if (!latest || busy) return;
  const autoNote = state.settings.autoInstall
    ? "\n\nAutomatic updates will be switched off so this version stays installed." : "";
  modal("Roll back to " + v(latest.version) + "?",
    "The current version (" + v(state.installedVersion) + ") will be kept as a backup, so you can switch back later. Your settings and characters are kept." + autoNote,
    [{ label: "Cancel" }, { label: "Roll back", primary: true, run: () => startRollback(latest) }]);
});

async function startRollback(backup) {
  if (busy) return;
  if (state.settings.autoInstall) { S.auto.checked = false; await persist(); }
  busy = true;
  showView("play");
  ui.notes.hidden = true;
  setButton("Working", null, false);
  setStatus("busy", "Rolling back to " + v(backup.version) + "…", "");
  setProgress("indeterminate");
  renderSettings();
  api.rollback(backup.name);
}

async function onRollbackDone(res) {
  busy = false;
  if (res.ok) {
    await refresh(false);
    setStatus("ready", "Ready to play", state.modName + " " + v(res.version) + " restored");
    ui.notesBtn.disabled = !release;
    if (res.warning) modal("Rolled back", res.warning, [{ label: "OK", primary: true }]);
    return;
  }
  setProgress(null);
  setButton(state.modInstalled ? "Play" : "Retry", state.modInstalled ? "play" : "retry");
  renderSettings();
  if (res.needsAdmin) {
    setStatus("error", "Windows needs your permission", "Your game folder is protected.");
    modal("Administrator permission needed",
      "Your game is installed in a protected folder, so Windows has to approve changes to it. Restart the launcher as administrator, then roll back again from Settings.",
      [{ label: "Cancel" }, { label: "Restart as administrator", primary: true, run: () => api.restartAsAdmin(false) }]);
  } else if (res.gameRunning) {
    setStatus("error", "Roll back failed", res.error || "");
    modal("Close the game first", "Diablo II: Resurrected is still running. Close it, then try again.", [{ label: "OK", primary: true }]);
  } else {
    setStatus("error", "Roll back failed", res.error || "Unknown error");
  }
}

// ---------- plugins tab ----------
const P = { list: $("pluginList"), install: $("installPluginBtn"), folder: $("pluginsFolderBtn"), toast: $("pluginToast") };
let plugins = null;
let pluginBusy = false;
let toastTimer = 0;

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}
function toast(msg) {
  P.toast.textContent = msg;
  P.toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => P.toast.classList.remove("show"), 2200);
}
function adminPrompt(what) {
  modal("Administrator permission needed",
    "Your game is installed in a protected folder, so Windows has to approve " + what + ". Restart the launcher as administrator, then try again.",
    [{ label: "Cancel" }, { label: "Restart as administrator", primary: true, run: () => api.restartAsAdmin(false) }]);
}
function pluginProblem(res, what) {
  if (res.needsAdmin) adminPrompt(what);
  else if (res.gameRunning) modal("Close the game first", "Plugins can't be changed while Diablo II: Resurrected is running.", [{ label: "OK", primary: true }]);
  else modal("Something went wrong", res.error || "Unknown error", [{ label: "OK", primary: true }]);
}

async function loadPlugins() {
  plugins = await api.listPlugins();
  renderPlugins();
}

function renderPlugins() {
  const L = P.list;
  L.innerHTML = "";
  P.install.disabled = pluginBusy || !plugins || !plugins.gameDirOk;
  if (!plugins) return;
  if (!plugins.gameDirOk) {
    const e = el("div", "empty");
    e.append(el("div", "glyph", "?"), el("p", "", "Set your game folder in Settings first."));
    L.append(e);
    return;
  }
  const items = plugins.items || [];
  const groups = [
    ["Your plugins", items.filter((p) => p.origin !== "mod")],
    ["Included with " + (state ? state.modName : "the mod"), items.filter((p) => p.origin === "mod")],
  ];
  if (!groups[0][1].length) {
    const e = el("div", "empty");
    e.append(el("div", "glyph", "✦"),
      el("p", "", "No plugins installed yet."),
      el("p", "hint", "Download a D2RLoader plugin (.zip) and choose Install plugin zip. The launcher puts each file in the right place."));
    L.append(e);
  }
  for (const [title, list] of groups) {
    if (!list.length) continue;
    if (groups[1][1].length) L.append(el("div", "pgroup", title));
    for (const p of list) L.append(pluginCard(p));
  }
}

function pluginCard(p) {
  const card = el("div", "pcard " + p.kind + (p.enabled ? "" : " off"));
  const icon = el("div", "picon", p.kind === "patch" ? "{ }" : (p.name || "?").trim().charAt(0).toUpperCase());
  const main = el("div", "pmain");
  const title = el("div", "ptitle");
  title.append(el("span", "pname", p.name || "Unnamed plugin"));
  if (p.version) title.append(el("span", "pver", v(p.version)));
  main.append(title);
  const desc = [p.description, p.author && "by " + p.author].filter(Boolean).join(" · ");
  if (desc) main.append(el("div", "pdesc", desc));
  const meta = el("div", "pmeta");
  meta.append(el("span", "chip" + (p.scope === "mod" ? " ember" : ""),
    p.scope === "mod" ? (state ? state.modName : "This mod") + " only" : "All mods"));
  meta.append(el("span", "chip", p.kind === "patch" ? "JSON patch" : p.kind === "data" ? "Data" : "Plugin"));
  if (p.origin === "found") meta.append(el("span", "chip", "Added outside the launcher"));
  if (!p.enabled) meta.append(el("span", "chip", "Off"));
  main.append(meta);
  const files = el("div", "pfiles", p.files.slice(0, 3).join("  ") + (p.files.length > 3 ? "  +" + (p.files.length - 3) + " more" : ""));
  files.title = p.files.join("\n");
  main.append(files);

  const actions = el("div", "pactions");
  if (p.canToggle) {
    const t = el("input", "toggle");
    t.type = "checkbox";
    t.checked = p.enabled;
    t.title = p.enabled ? "Turn off" : "Turn on";
    t.disabled = pluginBusy;
    t.addEventListener("change", async () => {
      const r = await api.setPluginEnabled(p.key, t.checked);
      if (!r.ok) { t.checked = !t.checked; pluginProblem(r, "changes to your plugins"); return; }
      toast(t.checked ? p.name + " turned on" : p.name + " turned off");
      loadPlugins();
    });
    actions.append(t);
  }
  if (p.canRemove) {
    const b = el("button", "btn small danger", "Remove");
    b.type = "button";
    b.disabled = pluginBusy;
    b.addEventListener("click", () => modal("Remove " + p.name + "?",
      "Its files move to the launcher's removed-plugins folder, so nothing is lost for good. Its settings file stays where it is.",
      [{ label: "Cancel" }, { label: "Remove", primary: true, run: async () => {
        const r = await api.removePlugin(p.key);
        if (!r.ok) { pluginProblem(r, "changes to your plugins"); return; }
        toast(p.name + " removed");
        loadPlugins();
      } }]));
    actions.append(b);
  }
  card.append(icon, main, actions);
  return card;
}

let planWaiter = null;
P.install.addEventListener("click", async () => {
  if (pluginBusy || planWaiter) return;
  const res = await new Promise((resolve) => { planWaiter = resolve; api.pickPluginZip(); });
  planWaiter = null;
  if (res.cancelled) return;
  if (res.error) {
    modal("Can't install " + (res.file || "that file"), res.error, [{ label: "OK", primary: true }]);
    return;
  }
  showInstallPlan(res);
});
P.folder.addEventListener("click", () => api.openPluginsFolder("global"));

function showInstallPlan(res) {
  const plan = res.plan;
  const node = el("div");
  node.append(el("p", "note", res.upgradeFrom
    ? "Already installed (" + v(res.upgradeFrom) + "). This replaces it; your plugin settings are kept."
    : "From " + res.fileName));
  const list = el("div", "plan-files");
  const kinds = { plugin: "Plugin", data: "Data", patch: "Patch", config: "Config" };
  for (const f of plan.files) {
    const row = el("div");
    row.append(el("span", "tag", kinds[f.kind] || f.kind), el("span", "", "d2rloader\\" + f.rel.replace(/\//g, "\\")));
    if (f.kind === "config" && f.exists) row.append(el("span", "keep", "keeps yours"));
    else if (f.exists) row.append(el("span", "keep", "replaces"));
    list.append(row);
  }
  node.append(list);
  if (plan.skipped && plan.skipped.length) {
    node.append(el("p", "note", "Skipped " + plan.skipped.length + " file" + (plan.skipped.length > 1 ? "s" : "") +
      " that D2RLoader doesn't load (" + plan.skipped.slice(0, 3).join(", ") + (plan.skipped.length > 3 ? ", …" : "") + ")."));
  }
  const pick = el("div", "scope-pick");
  const opt = (value, title, sub, disabled) => {
    const l = el("label");
    const r = el("input");
    r.type = "radio"; r.name = "scope"; r.value = value; r.disabled = !!disabled;
    r.checked = !disabled && value === (plan.suggestedScope === "mod" && res.modInstalled ? "mod" : "global");
    const t = el("span");
    t.append(el("b", "", title), el("small", "", sub));
    l.append(r, t);
    return l;
  };
  pick.append(
    opt("global", "All mods", "Goes in d2rloader\\plugins in your game folder. Right for most plugins."),
    opt("mod", res.modName + " only", res.modInstalled
      ? "Goes in the mod's own folder. Use this if the plugin's instructions say so. Kept across mod updates."
      : res.modName + " isn't installed yet.", !res.modInstalled));
  node.append(pick);

  const title = (res.upgradeFrom ? "Update " : "Install ") + plan.name + (plan.version ? " " + v(plan.version) : "") + "?";
  modal(title, "", [
    { label: "Cancel" },
    { label: res.upgradeFrom ? "Update" : "Install", primary: true, run: () => {
      const scope = (node.querySelector("input[name=scope]:checked") || {}).value || "global";
      installPluginFile(res.file, scope, plan.name);
    } },
  ], { wide: true, node });
}

function installPluginFile(file, scope, name) {
  pluginBusy = true;
  P.install.textContent = "Installing…";
  renderPlugins();
  api.installPlugin(file, scope);
}

async function onPluginInstalled(res) {
  pluginBusy = false;
  P.install.textContent = "Install plugin zip…";
  if (!res.ok) { renderPlugins(); pluginProblem(res, "installing plugins"); return; }
  toast((res.upgraded ? "Updated " : "Installed ") + res.name + (res.version ? " " + v(res.version) : ""));
  await loadPlugins();
}

window.__emit = (event, data) => {
  if (event === "check") onCheck(data);
  else if (event === "progress") onProgress(data);
  else if (event === "updateDone") onUpdateDone(data);
  else if (event === "folderChosen" && folderWaiter) folderWaiter(data);
  else if (event === "rollbackDone") onRollbackDone(data);
  else if (event === "pluginPlan" && planWaiter) planWaiter(data);
  else if (event === "pluginInstalled") onPluginInstalled(data);
};

// ---------- drifting embers ----------
const embers = (function () {
  const cv = $("embers"), ctx = cv.getContext("2d");
  let running = false;
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return { set() {} };
  let W = 0, H = 0, dpr = 1;
  const parts = [];
  function size() {
    dpr = window.devicePixelRatio || 1;
    W = innerWidth; H = innerHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function spawn(initial) {
    return {
      x: Math.random() * W,
      y: initial ? H * (0.35 + Math.random() * 0.65) : H + 6,
      vy: 0.25 + Math.random() * 0.65,
      sway: Math.random() * Math.PI * 2,
      r: 0.6 + Math.random() * 1.7,
      hue: 14 + Math.random() * 26,
      life: 0, max: 260 + Math.random() * 380,
    };
  }
  size(); addEventListener("resize", size);
  for (let i = 0; i < 46; i++) parts.push(spawn(true));
  let last = 0;
  function frame(t) {
    if (!running) { ctx.clearRect(0, 0, W, H); return; }
    if (t - last > 30) {           // ~30 fps is plenty for embers and keeps CPU low
      last = t;
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        p.life++; p.y -= p.vy; p.sway += 0.02; p.x += Math.sin(p.sway) * 0.35;
        const k = p.life / p.max;
        if (k >= 1 || p.y < -10) { parts[i] = spawn(false); continue; }
        const a = Math.sin(Math.PI * k) * 0.85;
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4);
        g.addColorStop(0, `hsla(${p.hue + 20},100%,75%,${a})`);
        g.addColorStop(0.35, `hsla(${p.hue},100%,55%,${a * 0.6})`);
        g.addColorStop(1, `hsla(${p.hue},100%,45%,0)`);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2); ctx.fill();
      }
    }
    requestAnimationFrame(frame);
  }
  return {
    set(on) {
      if (on === running) return;
      running = on;
      if (on) requestAnimationFrame(frame);
    },
  };
})();

refresh();
