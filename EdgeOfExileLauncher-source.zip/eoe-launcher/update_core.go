package main

// Platform-independent update logic: GitHub release lookup, download, zip extraction,
// preserving player-edited files, and swapping the new mod folder into place.

import (
	"archive/zip"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const versionFile = ".launcher-version"

type Release struct {
	Tag         string  `json:"tag_name"`
	Name        string  `json:"name"`
	Body        string  `json:"body"`
	PublishedAt string  `json:"published_at"`
	Assets      []Asset `json:"assets"`
}

type Asset struct {
	Name string `json:"name"`
	Size int64  `json:"size"`
	URL  string `json:"browser_download_url"`
}

var errNoRelease = errors.New("no release has been published yet")

func userAgent() string { return "EdgeOfExileLauncher/" + launcherVersion }

// fetchLatestRelease asks GitHub for the newest non-draft, non-prerelease release.
func fetchLatestRelease(ctx context.Context, repo string) (*Release, error) {
	ctx, cancel := context.WithTimeout(ctx, 20*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", "https://api.github.com/repos/"+repo+"/releases/latest", nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", userAgent())
	req.Header.Set("Accept", "application/vnd.github+json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, errors.New("couldn't reach GitHub (are you offline?)")
	}
	defer resp.Body.Close()
	switch {
	case resp.StatusCode == 404:
		return nil, errNoRelease
	case resp.StatusCode == 403 && resp.Header.Get("X-RateLimit-Remaining") == "0",
		resp.StatusCode == 429:
		return nil, errors.New("GitHub is rate-limiting update checks; try again in a few minutes")
	case resp.StatusCode != 200:
		return nil, fmt.Errorf("GitHub answered %s", resp.Status)
	}
	var rel Release
	if err := json.NewDecoder(io.LimitReader(resp.Body, 4<<20)).Decode(&rel); err != nil {
		return nil, fmt.Errorf("couldn't read GitHub's answer: %w", err)
	}
	return &rel, nil
}

// pickAsset returns the release asset to install: the configured name, or else the first .zip.
func pickAsset(rel *Release, want string) (*Asset, error) {
	for i, a := range rel.Assets {
		if want != "" && strings.EqualFold(a.Name, want) {
			return &rel.Assets[i], nil
		}
	}
	if want != "" {
		return nil, fmt.Errorf("release %s has no file named %s", rel.Tag, want)
	}
	for i, a := range rel.Assets {
		if strings.HasSuffix(strings.ToLower(a.Name), ".zip") {
			return &rel.Assets[i], nil
		}
	}
	return nil, fmt.Errorf("release %s has no .zip attached", rel.Tag)
}

// downloadFile streams url to dest, reporting progress. It writes to dest+".part" and renames when complete.
func downloadFile(ctx context.Context, url, dest string, wantSize int64, progress func(done, total int64)) error {
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", userAgent())
	req.Header.Set("Accept", "application/octet-stream")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return errors.New("download failed: couldn't reach GitHub")
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("download failed: GitHub answered %s", resp.Status)
	}
	total := resp.ContentLength
	if total <= 0 {
		total = wantSize
	}
	part := dest + ".part"
	f, err := os.Create(part)
	if err != nil {
		return err
	}
	var done int64
	buf := make([]byte, 256<<10)
	stall := time.AfterFunc(45*time.Second, func() { resp.Body.Close() })
	for {
		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			stall.Reset(45 * time.Second)
			if _, werr := f.Write(buf[:n]); werr != nil {
				f.Close()
				return werr
			}
			done += int64(n)
			progress(done, total)
		}
		if rerr == io.EOF {
			break
		}
		if rerr != nil {
			f.Close()
			stall.Stop()
			if ctx.Err() != nil {
				return ctx.Err()
			}
			return errors.New("download interrupted; check your connection and try again")
		}
	}
	stall.Stop()
	if err := f.Close(); err != nil {
		return err
	}
	if total > 0 && done != total {
		return fmt.Errorf("download incomplete (%d of %d bytes)", done, total)
	}
	os.Remove(dest)
	return os.Rename(part, dest)
}

// ---------- versions ----------

func normVersion(s string) string {
	s = strings.TrimSpace(s)
	return strings.TrimPrefix(strings.TrimPrefix(s, "v"), "V")
}

var numRe = regexp.MustCompile(`\d+`)

// compareVersions compares dotted versions numerically ("1.10.0" > "1.9.2").
// A pre-release suffix ("1.5.0-beta") sorts before the plain version.
func compareVersions(a, b string) int {
	a, b = normVersion(a), normVersion(b)
	ca, cb := strings.SplitN(a, "-", 2)[0], strings.SplitN(b, "-", 2)[0]
	na, nb := numRe.FindAllString(ca, -1), numRe.FindAllString(cb, -1)
	for i := 0; i < len(na) || i < len(nb); i++ {
		var x, y int
		if i < len(na) {
			x, _ = strconv.Atoi(na[i])
		}
		if i < len(nb) {
			y, _ = strconv.Atoi(nb[i])
		}
		if x != y {
			if x < y {
				return -1
			}
			return 1
		}
	}
	pa, pb := strings.Contains(a, "-"), strings.Contains(b, "-")
	switch {
	case pa && !pb:
		return -1
	case !pa && pb:
		return 1
	case pa && pb:
		return strings.Compare(strings.SplitN(a, "-", 2)[1], strings.SplitN(b, "-", 2)[1])
	}
	return 0
}

// installedVersion reads the version the launcher wrote, else the mod's own D2RLoader metadata.
func installedVersion(modDir string) (installed bool, version string) {
	if !looksLikeMod(modDir) {
		return false, ""
	}
	if b, err := os.ReadFile(filepath.Join(modDir, versionFile)); err == nil && strings.TrimSpace(string(b)) != "" {
		return true, normVersion(string(b))
	}
	var meta struct {
		Metadata struct {
			ModVersion string `json:"modVersion"`
		} `json:"metadata"`
	}
	if b, err := os.ReadFile(filepath.Join(modDir, "d2rloader", "metadata.json")); err == nil {
		if json.Unmarshal(b, &meta) == nil && meta.Metadata.ModVersion != "" {
			return true, normVersion(meta.Metadata.ModVersion)
		}
	}
	return true, "unknown"
}

// looksLikeMod reports whether dir holds a D2R folder mod (modinfo.json, an .mpq, or D2RLoader files).
func looksLikeMod(dir string) bool {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return false
	}
	for _, e := range entries {
		n := strings.ToLower(e.Name())
		if n == "modinfo.json" || n == "d2rloader" || strings.HasSuffix(n, ".mpq") {
			return true
		}
	}
	return false
}

// ---------- zip handling ----------

func isContentDir(name string) bool {
	n := strings.ToLower(name)
	return strings.HasSuffix(n, ".mpq") || n == "d2rloader" || n == "data"
}

// zipRoot finds the folder inside the zip that corresponds to mods/<Folder>/. Releases may be zipped
// as the mod folder itself, as mods/<Folder>/..., or as the mod's contents directly.
func zipRoot(files []*zip.File) (string, error) {
	prefix := ""
	for depth := 0; depth < 3; depth++ {
		tops := map[string]bool{}
		hasTopFile := false
		for _, f := range files {
			rel := strings.TrimPrefix(f.Name, prefix)
			if rel == "" || !strings.HasPrefix(f.Name, prefix) {
				continue
			}
			first, rest, found := strings.Cut(rel, "/")
			if !found || (rest == "" && !f.FileInfo().IsDir()) {
				hasTopFile = true
				continue
			}
			tops[first] = true
		}
		if hasTopFile || len(tops) != 1 {
			break
		}
		var only string
		for k := range tops {
			only = k
		}
		if isContentDir(only) {
			break
		}
		prefix += only + "/"
	}
	return prefix, nil
}

// extractZip unpacks the mod part of zipPath into dest.
func extractZip(zipPath, dest string, progress func(done, total int)) error {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return fmt.Errorf("the downloaded file isn't a valid zip: %w", err)
	}
	defer zr.Close()
	for _, f := range zr.File {
		f.Name = strings.ReplaceAll(f.Name, `\`, "/")
	}
	prefix, err := zipRoot(zr.File)
	if err != nil {
		return err
	}
	var todo []*zip.File
	for _, f := range zr.File {
		if strings.HasPrefix(f.Name, prefix) && strings.TrimPrefix(f.Name, prefix) != "" {
			todo = append(todo, f)
		}
	}
	if len(todo) == 0 {
		return errors.New("the release zip is empty")
	}
	for i, f := range todo {
		rel := path.Clean(strings.TrimPrefix(f.Name, prefix))
		if rel == "." || strings.HasPrefix(rel, "../") || rel == ".." || path.IsAbs(rel) || strings.Contains(rel, ":") {
			return fmt.Errorf("the release zip contains an unsafe path: %s", f.Name)
		}
		target := filepath.Join(dest, filepath.FromSlash(rel))
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
		} else if err := extractOne(f, target); err != nil {
			return err
		}
		progress(i+1, len(todo))
	}
	if !looksLikeMod(dest) {
		return errors.New("the release zip doesn't look like a D2R mod folder (no modinfo.json, .mpq or d2rloader folder)")
	}
	return nil
}

func extractOne(f *zip.File, target string) error {
	if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
		return err
	}
	rc, err := f.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	out, err := os.Create(target)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, rc); err != nil {
		out.Close()
		return fmt.Errorf("couldn't unpack %s: %w", f.Name, err)
	}
	if err := out.Close(); err != nil {
		return err
	}
	return os.Chtimes(target, f.Modified, f.Modified)
}

// ---------- install ----------

// preserveFiles copies each listed path (file or folder, relative to the mod folder) from the old
// install over the new one, so settings players changed survive updates.
func preserveFiles(oldDir, newDir string, patterns []string) error {
	for _, p := range patterns {
		p = strings.Trim(filepath.FromSlash(p), `\/`)
		if p == "" || strings.Contains(p, "..") {
			continue
		}
		src := filepath.Join(oldDir, p)
		info, err := os.Stat(src)
		if err != nil {
			continue
		}
		dst := filepath.Join(newDir, p)
		if !info.IsDir() {
			if err := copyFile(src, dst); err != nil {
				return err
			}
			continue
		}
		err = filepath.WalkDir(src, func(fp string, d os.DirEntry, err error) error {
			if err != nil || d.IsDir() {
				return err
			}
			rel, _ := filepath.Rel(src, fp)
			return copyFile(fp, filepath.Join(dst, rel))
		})
		if err != nil {
			return err
		}
	}
	return nil
}

func copyFile(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

var unsafeChars = regexp.MustCompile(`[^A-Za-z0-9._-]+`)

// swapIn moves the current mod folder into backups and the staged folder into its place.
// If the second step fails, the old folder is put back.
func swapIn(target, staged, backupsDir, oldVersion string, keep int) error {
	var backup string
	if _, err := os.Stat(target); err == nil {
		if err := os.MkdirAll(backupsDir, 0o755); err != nil {
			return err
		}
		ver := unsafeChars.ReplaceAllString(oldVersion, "_")
		if ver == "" {
			ver = "unknown"
		}
		backup = filepath.Join(backupsDir, filepath.Base(target)+"-"+ver+"-"+time.Now().Format("20060102-150405"))
		if err := os.Rename(target, backup); err != nil {
			return fmt.Errorf("couldn't move the old version aside (is the game or a file in it still open?): %w", err)
		}
	}
	if err := os.Rename(staged, target); err != nil {
		if backup != "" {
			os.Rename(backup, target)
		}
		return fmt.Errorf("couldn't move the new version into place: %w", err)
	}
	pruneBackups(backupsDir, filepath.Base(target)+"-", keep)
	return nil
}

func pruneBackups(dir, prefix string, keep int) {
	if keep < 0 {
		return
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	// Backup names end in -YYYYMMDD-HHMMSS, so the last 15 characters sort by age.
	stamp := func(name string) string {
		if len(name) < 15 {
			return name
		}
		return name[len(name)-15:]
	}
	var names []string
	for _, e := range entries {
		if e.IsDir() && strings.HasPrefix(e.Name(), prefix) {
			names = append(names, e.Name())
		}
	}
	sort.Slice(names, func(i, j int) bool { return stamp(names[i]) > stamp(names[j]) })
	for i := keep; i < len(names); i++ {
		os.RemoveAll(filepath.Join(dir, names[i]))
	}
}

// ---------- backups ----------

type BackupInfo struct {
	Name    string `json:"name"`
	Version string `json:"version"`
	When    string `json:"when"` // RFC 3339, local time
}

// listBackups returns backups of the mod folder, newest first. Names look like
// <Folder>-<version>-YYYYMMDD-HHMMSS (see swapIn).
func listBackups(dir, folder string) []BackupInfo {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil
	}
	prefix := folder + "-"
	var out []BackupInfo
	for _, e := range entries {
		n := e.Name()
		if !e.IsDir() || !strings.HasPrefix(n, prefix) || len(n) < len(prefix)+17 {
			continue
		}
		stamp := n[len(n)-15:]
		t, err := time.ParseInLocation("20060102-150405", stamp, time.Local)
		if err != nil {
			continue
		}
		out = append(out, BackupInfo{Name: n, Version: n[len(prefix) : len(n)-16], When: t.Format(time.RFC3339)})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].When > out[j].When })
	return out
}

// rollback puts a backup back in place of the current mod folder. The current folder becomes a
// backup itself, and the player's preserved files (their settings) carry over to the restored copy.
func rollback(target, backupsDir, backupName, currentVersion string, preserve []string, keep int) error {
	src := filepath.Join(backupsDir, backupName)
	if filepath.Base(src) != backupName || !looksLikeMod(src) {
		return errors.New("that backup is missing or damaged")
	}
	if err := preserveFiles(target, src, preserve); err != nil {
		return fmt.Errorf("couldn't carry over your settings: %w", err)
	}
	if keep < 1 {
		keep = 1 // never delete the version we just moved aside
	}
	return swapIn(target, src, backupsDir, currentVersion, keep)
}
